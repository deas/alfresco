Note: As of version 1.3, Solr no longer comes bundled with a Python client.  The existing client
was not sufficiently maintained or tested as development of Solr progressed, and committers
felt that the code was not up to our usual high standards of release.

The client bundled with previous versions of Solr will continue to be available indefinitely at:
http://svn.apache.org/viewvc/lucene/solr/tags/release-1.2.0/client/python/

Please see http://wiki.apache.org/solr/SolPython for information on third-party Solr python
clients.
