package org.jgroups;

/**
 * Trivial object that represents a block event.
 * @author Bela Ban
 * @version $Id: UnblockEvent.java,v 1.1 2006/09/27 12:33:06 belaban Exp $
 */
public class UnblockEvent {
    public String toString() {return "UnblockEvent";}
}
