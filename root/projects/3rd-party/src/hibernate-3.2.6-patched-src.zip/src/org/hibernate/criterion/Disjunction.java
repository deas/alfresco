package org.hibernate.criterion;


/**
 * @author Gavin King
 */
public class Disjunction extends Junction {

	protected Disjunction() {
		super("or");
	}

}
