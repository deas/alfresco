/**
 * Implementation of Spring Social's Service API for LinkedIn
 */
package org.springframework.social.linkedin.api.impl;
