/**
 * LinkedIn service provider connection repository and API adapter implementations. 
 */
package org.springframework.social.linkedin.connect;
