// Copyright 2006 Chibacon
/*
 *    Artistic License
 *
 *    Preamble
 *
 *    The intent of this document is to state the conditions under which a
 *    Package may be copied, such that the Copyright Holder maintains some
 *    semblance of artistic control over the development of the package,
 *    while giving the users of the package the right to use and distribute
 *    the Package in a more-or-less customary fashion, plus the right to make
 *    reasonable modifications.
 *
 *    Definitions:
 *
 *    "Package" refers to the collection of files distributed by the
 *    Copyright Holder, and derivatives of that collection of files created
 *    through textual modification.
 *
 *    "Standard Version" refers to such a Package if it has not been
 *    modified, or has been modified in accordance with the wishes of the
 *    Copyright Holder.
 *
 *    "Copyright Holder" is whoever is named in the copyright or copyrights
 *    for the package.
 *
 *    "You" is you, if you're thinking about copying or distributing this Package.
 *
 *    "Reasonable copying fee" is whatever you can justify on the basis of
 *    media cost, duplication charges, time of people involved, and so
 *    on. (You will not be required to justify it to the Copyright Holder,
 *    but only to the computing community at large as a market that must bear
 *    the fee.)
 *
 *    "Freely Available" means that no fee is charged for the item itself,
 *    though there may be fees involved in handling the item. It also means
 *    that recipients of the item may redistribute it under the same
 *    conditions they received it.
 *
 *    1. You may make and give away verbatim copies of the source form of the
 *    Standard Version of this Package without restriction, provided that you
 *    duplicate all of the original copyright notices and associated
 *    disclaimers.
 *
 *    2. You may apply bug fixes, portability fixes and other modifications
 *    derived from the Public Domain or from the Copyright Holder. A Package
 *    modified in such a way shall still be considered the Standard Version.
 *
 *    3. You may otherwise modify your copy of this Package in any way,
 *    provided that you insert a prominent notice in each changed file
 *    stating how and when you changed that file, and provided that you do at
 *    least ONE of the following:
 *
 *        a) place your modifications in the Public Domain or otherwise make
 *        them Freely Available, such as by posting said modifications to
 *        Usenet or an equivalent medium, or placing the modifications on a
 *        major archive site such as ftp.uu.net, or by allowing the Copyright
 *        Holder to include your modifications in the Standard Version of the
 *        Package.
 *
 *        b) use the modified Package only within your corporation or
 *        organization.
 *
 *        c) rename any non-standard executables so the names do not conflict
 *        with standard executables, which must also be provided, and provide
 *        a separate manual page for each non-standard executable that
 *        clearly documents how it differs from the Standard Version.
 *
 *        d) make other distribution arrangements with the Copyright Holder.
 *
 *    4. You may distribute the programs of this Package in object code or
 *    executable form, provided that you do at least ONE of the following:
 *
 *        a) distribute a Standard Version of the executables and library
 *        files, together with instructions (in the manual page or
 *        equivalent) on where to get the Standard Version.
 *
 *        b) accompany the distribution with the machine-readable source of
 *        the Package with your modifications.
 *
 *        c) accompany any non-standard executables with their corresponding
 *        Standard Version executables, giving the non-standard executables
 *        non-standard names, and clearly documenting the differences in
 *        manual pages (or equivalent), together with instructions on where
 *        to get the Standard Version.
 *
 *        d) make other distribution arrangements with the Copyright Holder.
 *
 *    5. You may charge a reasonable copying fee for any distribution of this
 *    Package. You may charge any fee you choose for support of this
 *    Package. You may not charge a fee for this Package itself.  However,
 *    you may distribute this Package in aggregate with other (possibly
 *    commercial) programs as part of a larger (possibly commercial) software
 *    distribution provided that you do not advertise this Package as a
 *    product of your own.
 *
 *    6. The scripts and library files supplied as input to or produced as
 *    output from the programs of this Package do not automatically fall
 *    under the copyright of this Package, but belong to whomever generated
 *    them, and may be sold commercially, and may be aggregated with this
 *    Package.
 *
 *    7. C or perl subroutines supplied by you and linked into this Package
 *    shall not be considered part of this Package.
 *
 *    8. The name of the Copyright Holder may not be used to endorse or
 *    promote products derived from this software without specific prior
 *    written permission.
 *
 *    9. THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 *    MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
package org.chiba.xml.xpath.test;

import junit.framework.TestCase;
import org.chiba.xml.xpath.XPathReferenceFinder;
import org.chiba.xml.xpath.impl.JXPathReferenceFinderImpl;

import java.util.Set;

/**
 * Tests reference detection.
 *
 * @author Adrian Baker
 * @author Ulrich Nicolas Liss&eacute;
 * @version $Id: XPathReferenceFinderTest.java,v 1.1 2006/08/18 21:01:24 unl Exp $
 */
public class XPathReferenceFinderTest extends TestCase {

    private XPathReferenceFinder referenceFinder;

    /**
     * Tests reference detection for fairly simple expressions.
     *
     * @throws Exception if an error occurred during the test.
     */
    public void testGetReferences() throws Exception {
        assertReferences(new String[]{"data"},
                this.referenceFinder.getReferences("data"));
        assertReferences(new String[]{"observation/data"},
                this.referenceFinder.getReferences("observation/data"));
        assertReferences(new String[]{"observation[data != '']", "observation/data"},
                this.referenceFinder.getReferences("observation[data != '']"));
        assertReferences(new String[]{"observation[data != '']", "observation/data"},
                this.referenceFinder.getReferences("count(observation[data != '']) > 0"));
        assertReferences(new String[]{"observation[data != '']/code", "observation/data"},
                this.referenceFinder.getReferences("count(observation[data != '']/code) > 0"));
        assertReferences(new String[]{"/observation[data != '']/code", "/observation/data"},
                this.referenceFinder.getReferences("count(/observation[data != '']/code) > 0"));
        assertReferences(new String[]{"observation[/data != '']/code", "/data"},
                this.referenceFinder.getReferences("count(observation[/data != '']/code) > 0"));
        assertReferences(new String[]{"/observation[/data != '']/code", "/data"},
                this.referenceFinder.getReferences("count(/observation[/data != '']/code) > 0"));
    }

    /**
     * Tests reference detection for expressions with instance() function.
     *
     * @throws Exception if an error occurred during the test.
     */
    public void testGetReferencesWithInstanceFunction() throws Exception {
        assertReferences(new String[]{"instance('test')"},
                this.referenceFinder.getReferences("instance('test')"));
        assertReferences(new String[]{"instance('test')"},
                this.referenceFinder.getReferences("count(instance('test'))"));
        assertReferences(new String[]{"instance('test')/observation[data != '']", "instance('test')/observation/data"},
                this.referenceFinder.getReferences("count(instance('test')/observation[data != '']) > 0"));
        assertReferences(new String[]{"instance('test')/observation[data != instance('list')/@data]", "instance('test')/observation/data", "instance('list')/@data"},
                this.referenceFinder.getReferences("count(instance('test')/observation[data != instance('list')/@data]) > 0"));
        assertReferences(new String[]{"consumerId", "instance('version-data')/selectedVersion", "instance('editModes')/editable"},
                this.referenceFinder.getReferences("concat(concat('sampleConsentQuestionnaireWorkflow?consumerId=', consumerId), if(instance('version-data')/selectedVersion != '', concat('&versionNumber=', instance('version-data')/selectedVersion), ''), '&editable=', instance('editModes')/editable)"));
        assertReferences(new String[]{"instance('x')", "data", "../no/data", "instance('y')/node", "element[@id = instance('z')]", "element/@id", "instance('z')"},
                this.referenceFinder.getReferences("concat(instance('x'), data or ../no/data, instance('y')/node, element[@id = instance('z')])"));
        assertReferences(new String[]{"instance('i')", "ext:function()[@id = /data/id]/value", "ext:function()/@id", "/data/id"},
                this.referenceFinder.getReferences("instance('i') or ext:function()[@id = /data/id]/value"));
    }

    /**
     * Sets up the test.
     *
     * @throws Exception in any error occurred during setup.
     */
    protected void setUp() throws Exception {
        this.referenceFinder = new JXPathReferenceFinderImpl();
    }

    /**
     * Tears down the test.
     *
     * @throws Exception in any error occurred during setup.
     */
    protected void tearDown() throws Exception {
        this.referenceFinder = null;
    }

    private void assertReferences(String[] expected, Set actual) throws Exception {
        if (expected == null) {
            assertEquals(null, actual);
            return;
        }

        assertEquals("number of references:", expected.length, actual.size());
        for (int i = 0; i < expected.length; i++) {
            assertEquals("reference to " + expected[i] + ":", true, actual.contains(expected[i]));
        }
    }

}
