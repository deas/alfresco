/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query;

import javax.jcr.RepositoryException;
import javax.jcr.Node;

/**
 * This interface encapsulates methods for the management of search queries.
 * Provides methods for the creation and retrieval of search queries.
 *
 */
public interface QueryManager {

    /**
     * Creates a new query by specifying the query <code>statement</code> itself and the
     * <code>language</code> in which the query is stated. If the query <code>statement</code> is
     * syntactically invalid, given the language specified, an
     * <code>InvalidQueryException</code> is thrown. The <code>language</code> must
     * be a string from among those returned by QueryManager.getSupportedQueryLanguages();
     * if it is not, then an <code>InvalidQueryException</code> is thrown.
     *
     * @throws InvalidQueryException if statement is invalid or language is unsupported.
     * @throws RepositoryException if another error occurs
     * @return A <code>Query</code> object.
     */
    public Query createQuery(String statement, String language) throws InvalidQueryException, RepositoryException;

    /**
     * Retrieves an existing persistent query. If <code>node</code>
     * is not a valid persisted query (that is, a node of type
     * <code>nt:query</code>), an <code>InvalidQueryException</code>
     * is thrown.
     * <p/>
     * Persistent queries are created by first using <code>QueryManager.createQuery</code>
     * to create a <code>Query</code> object and then calling <code>Query.save</code> to
     * persist the query to a location in the workspace.
     *
     * @param node a persisted query (that is, a node of type <code>nt:query</code>).
     * @throws InvalidQueryException If <code>node</code> is not a valid persisted query
     * (that is, a node of type <code>nt:query</code>).
     * @throws RepositoryException if another error occurs
     * @return a <code>Query</code> object.
     */
    public Query getQuery(Node node) throws InvalidQueryException, RepositoryException;

    /**
     * Returns an array of strings representing all query languages supported by this repository.
     * In level 1 this set must include the string represented by the constant {@link Query#XPATH}.
     * If SQL is supported it must additionally include the string represented by the constant {@link Query#SQL}.
     * An implementation may also support other languages as well.
     *
     * See {@link Query}.
     * @return An string array.
     * @throws RepositoryException if an error occurs.
     */
    public String[] getSupportedQueryLanguages() throws RepositoryException;
}
