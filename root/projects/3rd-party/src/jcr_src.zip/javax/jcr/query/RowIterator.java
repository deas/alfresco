/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query;

import javax.jcr.RangeIterator;

public interface RowIterator extends RangeIterator {

     /**
      * Returns the next <code>Row</code> in the iteration.
      *
      * @return the next <code>Row</code> in the iteration.
      * @throws java.util.NoSuchElementException if iteration has no more <code>Row</code>s.
     */
    public Row nextRow();
}

