/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query;

import javax.jcr.*;

/**
 * A QueryResult object. Returned by {@link javax.jcr.query.Query#execute()}.
 */
public interface QueryResult {

    /**
     * Returns an array of all the property names (column names) in this result set.
     *
     * @return a <code>PropertyIterator</code>
     * @throws RepositoryException if an error occurs.
     */
    public String[] getColumnNames() throws RepositoryException;

    /**
     * Returns an iterator over the <code>Row</code>s of the query result table.
     * If an <code>ORDER BY</code> clause was specified in the query, then the
     * order of the returned properties in the iterator will reflect the order
     * specified in that clause. If no items match, an empty iterator is returned.
     *
     * @return a <code>RowIterator</code>
     * @throws RepositoryException if an error occurs.
     */
    public RowIterator getRows() throws RepositoryException;

    /**
     * Returns an iterator over all nodes that match the query. If an <code>ORDER BY</code>
     * clause was specified in the query, then the order of the returned nodes in the iterator
     * will reflect the order specified in that clause. If no nodes match, an empty iterator
     * is returned.
     *
     * @return a <code>NodeIterator</code>
     * @throws RepositoryException if an error occurs.
     */
    public NodeIterator getNodes() throws RepositoryException;
}