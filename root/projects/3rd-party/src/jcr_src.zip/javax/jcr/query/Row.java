/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query;

import javax.jcr.Value;
import javax.jcr.RepositoryException;
import javax.jcr.ItemNotFoundException;

/**
 * A row in the query result table.
 */
public interface Row {

    /**
     * Returns an array of all the values in the same order as the
     * column names returned by {@link QueryResult#getColumnNames()}.
     *
     * @return a <code>Value</code> array.
     * @throws RepositoryException if an error occurs
     */
    public Value[] getValues() throws RepositoryException;

    /**
     * Returns the value of the indicated  property in this <code>Row</code>.
     * <p/>
     * If <code>propertyName</code> is not among the column names of the query result
     * table, an <code>ItemNotFoundException</code> is thrown.
     *
     * @return a <code>Value</code>
     * @throws ItemNotFoundException if <code>propertyName</code> s not among the
     * column names of the query result table
     * @throws RepositoryException if anopther error occurs.
     */
    public Value getValue(String propertyName) throws ItemNotFoundException, RepositoryException;
}
