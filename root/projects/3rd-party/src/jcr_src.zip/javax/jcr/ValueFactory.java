/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import java.io.InputStream;
import java.util.Calendar;

/**
 * The <code>ValueFactory</code> object provides methods for the creation Value objects that can then
 * be used to set properties.
 */
public interface ValueFactory {

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#STRING}
     * with the specified <code>value</code>.
     *
     * @param value a <code>String</code>
     * @return a <code>Value</code> of {@link PropertyType#STRING}
     */
    public Value createValue(String value);

    /**
     * Returns a <code>Value</code> object of the {@link PropertyType} specified by <code>type</code>
     * with the specified <code>value</code>.
     *
     * A <code>ValueFormatException</code> is thrown if the specified <code>value</code> cannot
     * be converted to the specifed <code>type</code>.
     *
     * @param value a <code>String</code>
     * @param type one of the constants defined in {@link PropertyType}.
     * @return a <code>Value</code> of {@link PropertyType} <code>type</code>.
     * @throws ValueFormatException if the specified <code>value</code> cannot
     * be converted to the specifed <code>type</code>.
     */
    public Value createValue(String value, int type) throws ValueFormatException;

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#LONG}
     * with the specified <code>value</code>.
     *
     * @param value a <code>long</code>
     * @return a <code>Value</code> of {@link PropertyType#LONG}
     */
    public Value createValue(long value);

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#DOUBLE}
     * with the specified <code>value</code>.
     *
     * @param value a <code>double</code>
     * @return a <code>Value</code> of {@link PropertyType#DOUBLE}
     */
    public Value createValue(double value);

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#BOOLEAN}
     * with the specified <code>value</code>.
     *
     * @param value a <code>boolean</code>
     * @return a <code>Value</code> of {@link PropertyType#BOOLEAN}
     */
    public Value createValue(boolean value);

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#DATE}
     * with the specified <code>value</code>.
     *
     * @param value a <code>Calendar</code>
     * @return a <code>Value</code> of {@link PropertyType#DATE}
     */
    public Value createValue(Calendar value);

    /**
     * Returns a <code>Value</code> object of <code>PropertyType.BINARY</code>
     * with a value consisting of the content of the specified <code>InputStream</code>.
     *
     * @param value an <code>InputStream</code>
     * @return a <code>Value</code> of {@link PropertyType#BINARY}
     */
    public Value createValue(InputStream value);

    /**
     * Returns a <code>Value</code> object of {@link PropertyType#REFERENCE}
     * that holds the UUID of the specified <code>Node</code>. This <code>Value</code>
     * object can then be used to set a property that will be a reference to that
     * <code>Node</code>.<p/>
     * <p/>
     * A <code>RepositoryException</code> is thrown if the specified <code>Node</code>
     * is not referencable, the current <code>Session</code> is no longer active, or another
     * error occurs.
     *
     * @param value a <code>Node</code>
     * @return a <code>Value</code> of {@link PropertyType#REFERENCE}
     * @throws RepositoryException if the specified <code>Node</code>
     * is not referencable, the current <code>Session</code> is no longer active, or another
     * error occurs.
     */
    public Value createValue(Node value) throws RepositoryException;
}
