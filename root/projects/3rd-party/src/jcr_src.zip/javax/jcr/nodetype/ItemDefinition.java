package javax.jcr.nodetype;

/**
 * Superinterface of {@link NodeDefinition} and {@link PropertyDefinition}.
 *
 */
public interface ItemDefinition {
    /**
     * Gets the node type that contains the declaration of <i>this</i>
     * <code>ItemDefinition</code>.
     *
     * @return a <code>NodeType</code> object.
     */
    NodeType getDeclaringNodeType();

    /**
     * Gets the name of the child item. If <code>"*"</code>, this
     * <code>ItemDefinition</code> defines a residual set of child items. That is,
     * it defines the characteristics of all those child items with names apart
     * from the names explicitly used in other child item definitions.
     *
     * @return a <code>String</code> denoting the name or <code>"*"</code>.
     */
    String getName();

    /**
     * Reports whether the item is to be automatically created when its parent node is created.
     * If <code>true</code>, then this <code>ItemDefinition</code> will necessarily not be a residual
     * set definition but will specify an actual item name (in other words getName() will not
     * return �*�).
     *
     * @return a <code>boolean</code>.
     */
    boolean isAutoCreated();

    /**
     * Reports whether the item is mandatory. A mandatory item is one that,
     * if its parent node exists, must also exist.
     *<p/>
     * This means that a mandatory single-value property
     * must have a value (since there is no such thing a <code>null</code> value).
     * In the case of multi-value properties this means that the property must exist,
     * though it can have zero or more values.
     * <p/>
     * An attempt to save a node that has a mandatory child item without first
     * creating that child item  will throw a
     * <code>ConstraintViolationException</code> on <code>save</code>.
     *
     * @return a <code>boolean</code>
     */
    boolean isMandatory();

    /**
     * Gets the on-parent-version status of the child item. This governs what to do if
     * the parent node of this child item is versioned; an
     * {@link javax.jcr.version.OnParentVersionAction}.
     *
     * @return an <code>int</code>.
     */
    int getOnParentVersion();

    /**
     * Reports whether the child item is protected. In level 2 implementations, a protected item is one that cannot be removed
     * (xcept by removing its parent) or modified through the the standard write methods of this API (that is, <code>Item.remove</code>,
     * <code>Node.addNode</code>, <code>Node.setProperty</code> and <code>Property.setValue</code>).
     * <p/>
     * A protected node may be removed or modified (in a level 2 implementation), however, through some
     * mechanism not defined by this specification or as a side-effect of operations other than
     * the standard write methods of the API.
     *
     * @return a <code>boolean</code>.
     */
    boolean isProtected();
}
