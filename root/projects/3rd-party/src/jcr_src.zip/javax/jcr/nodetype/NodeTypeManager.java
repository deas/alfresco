/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.nodetype;

import javax.jcr.RepositoryException;
import javax.jcr.Workspace;

/**
 * Allows for the retrieval of node types.
 * Accessed via {@link Workspace#getNodeTypeManager}.
 *
 */
public interface NodeTypeManager {

    /**
     * Returns the named node type.
     * <p>
     * Throws a <code>NoSuchNodeTypeException</code> if a node type by that name does not exist.
     * <p>
     * Throws a <code>RepositoryException</code> if another error occurs.
     *
     * @param nodeTypeName the name of an existing node type.
     * @return A <code>NodeType</code> object.
     * @throws NoSuchNodeTypeException if no node type by the given name exists.
     * @throws RepositoryException if another error occurs.
     */
    public NodeType getNodeType(String nodeTypeName) throws NoSuchNodeTypeException, RepositoryException;

    /**
     * Returns an iterator over all available node types (primary and mixin).
     *
     * @return An <code>NodeTypeIterator</code>.
     *
     * @throws RepositoryException if an error occurs.
     */
    public NodeTypeIterator getAllNodeTypes() throws RepositoryException;

    /**
     * Returns an iterator over all available primary node types.
     *
     * @return An <code>NodeTypeIterator</code>.
     *
     * @throws RepositoryException if an error occurs.
     */
    public NodeTypeIterator getPrimaryNodeTypes() throws RepositoryException;

    /**
     * Returns an iterator over all available mixin node types.
     * If none are available, an empty iterator is returned.
     *
     * @return An <code>NodeTypeIterator</code>.
     *
     * @throws RepositoryException if an error occurs.
     */
    public NodeTypeIterator getMixinNodeTypes() throws RepositoryException;
}