/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.nodetype;

/**
 * A node definition. Used in node type definitions.
 *
 * @see NodeType#getChildNodeDefinitions
 * @see javax.jcr.Node#getDefinition
 *
 */
public interface NodeDefinition extends ItemDefinition {

    /**
     * Gets the minimum set of primary node types that the child node must have.
     * Returns an array to support those implementations with multiple inheritance.
     * This method never returns an empty array. If this node definition places no
     * requirements on the primary node type, then this method will return an array
     * containing only the <code>NodeType</code> object representing <code>nt:base</code>,
     * which is the base of all primary node types and therefore constitutes the least
     * restrictive node type requirement. Note that any particular node instance still
     * has only one assigned primary node type, but in multiple-inheritance-supporting
     * implementations the <code>RequiredPrimaryTypes</code> attribute can be used to
     * restrict that assigned node type to be a subtype of <i>all<i> of a specified set
     * of node types.
     *
     * @return an array of <code>NodeType</code> objects.
     */
    public NodeType[] getRequiredPrimaryTypes();

    /**
     * Gets the default primary node type that will be assigned to the child
     * node if it is created without an explicitly specified primary node type.
     * This node type must be a subtype of (or the same type as) the node types
     * returned by <code>getRequiredPrimaryTypes</code>.
     * <p/>
     * If <code>null</code> is returned this indicates that no default primary
     * type is specified and that therefore an attempt to create this node without
     * specifying a node type will throw a <code>ConstraintViolationException</code>.
     *
     * @return a <code>NodeType</code>.
     */
    public NodeType getDefaultPrimaryType();

    /**
     * Reports whether this child node can have same-name siblings. In other
     * words, whether the parent node can have more than one child node of this
     * name.
     *
     * @return a boolean.
     */
    public boolean allowsSameNameSiblings();
}