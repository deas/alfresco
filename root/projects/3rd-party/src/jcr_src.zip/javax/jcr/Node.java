/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import javax.jcr.lock.Lock;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.nodetype.NodeDefinition;
import javax.jcr.nodetype.NodeType;
import javax.jcr.version.Version;
import javax.jcr.version.VersionException;
import javax.jcr.version.VersionHistory;
import java.io.InputStream;
import java.util.Calendar;

/**
 * The <code>Node</code> interface represents a node in the hierarchy that
 * makes up the repository.
 */
public interface Node extends Item {

    /**
     * Creates a new node at <code>relPath</code>. The new node will only be
     * persisted on <code>save()</code> if it meets the constraint
     * criteria of the parent node's node type.
     * <p/>
     * In order to save a newly added node, <code>save</code> must be called
     * either on the <code>Session</code>, or on the new node's parent or higher-order
     * ancestor (grandparent, etc.). An attempt to call <code>save</code> <i>only</i>
     * on the newly added node will throw a <code>RepositoryException</code>.
     * <p/>
     * In the context of this method the <code>relPath</code> provided must not
     * have an index on its final element. If it does then a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * Strictly speaking, the parameter is actually a relative path to the parent node
     * of the node to be added, appended with the name desired for the
     * new node (if the a node is being added directly below <code>this</code> node then only
     * the name need be specified). It does not specify a position within the child node
     * ordering. If ordering is supported by the node type of
     * the parent node then the new node is appended to the end of the
     * child node list.
     * <p/>
     * Since this signature does not allow explicit node type assignment, the new
     * node's primary node type will be determined (either immediately or on
     * <code>save</code>, depending on the implementation) by the child node definitions in
     * the node types of its parent.
     * <p/>
     * An <code>ItemExistsException</code> will be thrown either immediately (by this
     * method), or on <code>save</code>, if an item at the specified path already exists and
     * same-name siblings are not allowed. Implementations may differ on when
     * this validation is performed.
     * <p/>
     * A <code>PathNotFoundException</code> will be thrown
     * either immediately,  or on <code>save</code>, if the specified path
     * implies intermediary nodes that do not exist. Implementations may differ
     * on when this validation is performed.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if adding the
     * node would violate a node type or implementation-specific constraint or
     * if an attempt is made to add a node as the child of a property.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately  or
     * on <code>save</code>, if the node to which the new child is being added is versionable
     * and checked-in or is non-versionable but its nearest versionable ancestor
     * is checked-in. Implementations may differ on when this validation is
     * performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately (by this
     * method), or on <code>save</code>, if a lock prevents the addition of the node.
     * Implementations may differ on when this validation is performed.
     *
     * @param relPath The path of the new node to be created.
     *
     * @return The node that was added.
     *
     * @throws ItemExistsException if an item at the specified path already exists,
     * same-name siblings are not allowed and this implementation performs this
     * validation immediately instead of waiting until <code>save</code>.
     *
     * @throws PathNotFoundException if the specified path implies intermediary
     * <code>Node</code>s that do not exist or the last element of
     * <code>relPath</code> has an index, and this implementation performs this
     * validation immediately instead of waiting until <code>save</code>.
     *
     * @throws ConstraintViolationException if a node type or implementation-specific constraint
     * is violated or if an attempt is made to add a node as the child of a property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws VersionException if the node to which the new child is being added is versionable and
     * checked-in or is non-versionable but its nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws LockException if a lock prevents the addition of the node and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws RepositoryException If the last element of <code>relPath</code> has an index or if another error occurs.
     */
    public Node addNode(String relPath) throws ItemExistsException, PathNotFoundException, VersionException, ConstraintViolationException, LockException, RepositoryException;

    /**
     * Creates a new node at <code>relPath</code> of the specified node type.
     * The same as <code>{@link #addNode(String relPath)}</code> except that the primary
     * node type of the new node is explictly specified.
     * <p/>
     * An <code>ItemExistsException</code> will be thrown either immediately (by this
     * method), or on <code>save</code>, if an item at the specified path already exists and
     * same-name siblings are not allowed. Implementations may differ on when
     * this validation is performed.
     * <p/>
     * A <code>PathNotFoundException</code> will be thrown
     * either immediately,  or on <code>save</code>, if the specified path
     * implies intermediary nodes that do not exist. Implementations may differ
     * on when this validation is performed.
     * <p/>
     * A NoSuchNodeTypeException will be thrown either immediately
     * or on <code>save</code>, if the specified node type is not recognized.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if adding the
     * node would violate a node type or implementation-specific constraint or
     * if an attempt is made to add a node as the child of a property.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately  or
     * on <code>save</code>, if the node to which the new child is being added is versionable
     * and checked-in or is non-versionable but its nearest versionable ancestor
     * is checked-in. Implementations may differ on when this validation is
     * performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately (by this
     * method), or on <code>save</code>, if a lock prevents the addition of the node.
     * Implementations may differ on when this validation is performed.
     *
     * @param relPath the path of the new node to be created.
     *
     * @param primaryNodeTypeName The name of the primary node type of the new node.
     *
     * @return the node that was added.
     *
     * @throws ItemExistsException if an item at the specified path already exists,
     * same-name siblings are not allowed and this implementation performs this
     * validation immediately instead of waiting until <code>save</code>.
     *
     * @throws PathNotFoundException if the specified path implies intermediary
     * <code>Node</code>s that do not exist or the last element of
     * <code>relPath</code> has an index, and this implementation performs this
     * validation immediately instead of waiting until <code>save</code>.
     *
     * @throws NoSuchNodeTypeException if the specified node type is not recognized and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws ConstraintViolationException if a node type or implementation-specific constraint
     * is violated or if an attempt is made to add a node as the child of a property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws VersionException if the node to which the new child is being added is versionable and
     * checked-in or is non-versionable but its nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws LockException if a lock prevents the addition of the node and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     *
     * @throws RepositoryException if the last element of <code>relPath</code> has an index or if
     * another error occurs.
     */
    public Node addNode(String relPath, String primaryNodeTypeName) throws ItemExistsException, PathNotFoundException, NoSuchNodeTypeException, LockException, VersionException, ConstraintViolationException, RepositoryException;

    /**
     * If this node supports child node ordering, this method inserts the child node at
     * <code>srcChildRelPath</code> before its sibling, the child node at <code>destChildRelPath</code>,
     * in the child node list.
     * <p/>
     * To place the node <code>srcChildRelPath</code> at the end of the list, a <code>destChildRelPath</code>
     * of <code>null</code> is used.
     * <p/>
     * Note that (apart from the case where <code>destChildRelPath</code> is <code>null</code>) both of these
     * arguments must be relative paths of depth one, in other words they are the names of the child nodes,
     * possibly suffixed with an index.
     * <p/>
     * If <code>srcChildRelPath</code> and <code>destChildRelPath</code> are the same, then no change is made.
     * <p/>
     * Changes to ordering of child nodes are persisted on <code>save</code> of the parent node. But, if this node
     * does not support child node ordering, then a <code>UnsupportedRepositoryOperationException</code>
     * thrown.
     * <p/>
     * If <code>srcChildRelPath</code> is not the relative path to a child node of this node then an
     * <code>ItemNotFoundException</code> is thrown.
     * <p/>
     * If <code>destChildRelPath</code> is neither the relative path to a child node of this node nor
     * <code>null</code>, then an <code>ItemNotFoundException</code> is also thrown.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if this operation would
     * violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately  or
     * on <code>save</code>, if this node is versionable
     * and checked-in or is non-versionable but its nearest versionable ancestor
     * is checked-in. Implementations may differ on when this validation is
     * performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately (by this
     * method), or on <code>save</code>, if a lock prevents the re-ordering.
     * Implementations may differ on when this validation is performed.
     *
     * @param srcChildRelPath  the relative path to the child node (that is, name plus possible index)
     * to be moved in the ordering
     * @param destChildRelPath the the relative path to the child node (that is, name plus possible index)
     * before which the node <code>srcChildRelPath</code> will be placed.
     * @throws UnsupportedRepositoryOperationException if ordering is not supported.
     * @throws ConstraintViolationException if an implementation-specific ordering restriction is violated
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ItemNotFoundException        if either parameter is not the relative path of a child node of this node.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this implementation performs this validation immediately instead
     * of waiting until <code>save</code>..
     * @throws LockException if a lock prevents the re-ordering and this implementation performs this validation
     * immediately instead of waiting until <code>save</code>..
     * @throws RepositoryException if another error occurs.
     */
    public void orderBefore(String srcChildRelPath, String destChildRelPath) throws UnsupportedRepositoryOperationException, VersionException, ConstraintViolationException, ItemNotFoundException, LockException, RepositoryException;

    /**
     * Sets the specified (single-value) property of this node to the specified
     * <code>value</code>. If the property does not yet exist, it is created.
     * The property type of the property will be that specified by the node type
     * of this node.
     * <p/>
     * If the property type of the supplied <code>Value</code> object is different
     * from that required, then a best-effort conversion is attempted. If the
     * conversion fails, a <code>ValueFormatException</code> is thrown. If another
     * error occurs, a <code>RepositoryException</code> is thrown.
     * <p/>
     * If the node type of this node does not indicate a specific property
     * type, then the property type of the supplied <code>Value</code> object
     * is used and if the property already exists it assumes both the new value
     * and new property type.
     * <p/>
     * If the property is multi-valued, a <code>ValueFormatException</code>
     * is thrown.
     *  <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Value)null)</code> would remove
     * property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to be assigned
     * @return The updated <code>Property</code> object
     *
     * @throws ValueFormatException if <code>value</code> cannot be converted to the type of the specified
     * property or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public Property setProperty(String name, Value value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified (single-value) property to the specified value.
     * If the property does not yet exist, it is created.
     * <p/>
     * The type of the new property is determined by the <code>type</code> parameter specified.
     * <p/>
     * If the property type of the supplied <code>Value</code> object is different from that
     * required, then a best-effort conversion is attempted. If the conversion fails, a
     * <code>ValueFormatException</code> is thrown.
     * <p/>
     * If the property is not single-valued then a <code>ValueFormatException</code> is also thrown.
     * <p/>
     * If the property already exists it assumes both the new value and the new property type.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Value)null, type)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To persist the addition or removal of a property, <code>save</code> must be called
     * on the <code>Session</code>, this <code>Node</code>, or an ancestor of this <code>Node</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name the name of the property to be set.
     * @param value a <code>Value</code> object.
     * @param type the type of the property.
     *
     * @return the <code>Property</code> object set, or <code>null</code>
     * if this method was used to remove a property (by setting its value to <code>null</code>).
     *
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the specified type
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public Property setProperty(String name, Value value, int type) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified (multi-value) property to the specified array of values.
     * If the property does not yet exist, it is created. Same as
     * {@link #setProperty(String name, Value value)} except that an array of
     * <code>Value</code> objects is assigned instead of a single <code>Value</code>.
     * <p/>
     * The property type of the property will be that specified by the node type of this node.
     * If the property type of the supplied <code>Value</code> objects is different from that
     * required, then a best-effort conversion is attempted. If the conversion fails, a
     * <code>ValueFormatException</code> is thrown.
     * <p/>
     * All <code>Value</code> objects in the array must be of the same type, otherwise a
     * <code>ValueFormatException</code> is thrown. If the property is not multi-valued
     * then a <code>ValueFormatException</code> is also thrown. If another error occurs,
     * a <code>RepositoryException</code> is thrown.
     * <p/>
     * If the node type of this node does not indicate a specific property type, then the
     * property type of the supplied <code>Value</code> objects is used and if the
     * property already exists it assumes both the new values and the new property type.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Value[])null)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * Note that this is different from passing an array that contains <code>null</code>
     * elements. In such a case, the array is compacted by removing the <code>null</code>s.
     * The resulting set of values never contains nulls. However, the set may be empty:
     * <code>N.setProperty("P", new Value[]{null})</code> would set the property to
     * the empty set of values.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name   the name of the property to be set.
     * @param values an array of <code>Value</code> objects.
     * @return the updated <code>Property</code> object.
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is not multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          if another error occurs.
     */
    public Property setProperty(String name, Value[] values) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified (multi-value) property to the specified array of values.
     * If the property does not yet exist, it is created. The type of the property
     * is determined by the <code>type</code> parameter specified.
     * <p/>
     * If the property type of the supplied <code>Value</code> objects is different from that
     * specified, then a best-effort conversion is attempted. If the conversion fails, a
     * <code>ValueFormatException</code> is thrown.
     * <p/>
     * If the property already exists it assumes both the new values and the new property type.
     * <p/>
     * All <code>Value</code> objects in the array must be of the same type, otherwise a
     * <code>ValueFormatException</code> is thrown. If the property is not multi-valued
     * then a <code>ValueFormatException</code> is also thrown. If another error occurs,
     * a <code>RepositoryException</code> is thrown.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Value[])null, type)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * Note that this is different from passing an array that contains <code>null</code>
     * elements. In such a case, the array is compacted by removing the <code>null</code>s.
     * The resulting set of values never contains nulls. However, the set may be empty:
     * <code>N.setProperty("P", new Value[]{null}, type)</code> would set the property to
     * the empty set of values.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name   the name of the property to be set.
     * @param values an array of <code>Value</code> objects.
     * @param type   the type of the property.
     * @return the updated <code>Property</code> object.
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the specified type
     * or if the property already exists and is not multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          if another error occurs.
     */
    public Property setProperty(String name, Value[] values, int type) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified array of values.
     * Same as {@link #setProperty(String name, Value[] values)}
     * except that the values are specified as <code>String</code>
     * objects instead of <code>Value</code> objects.
     *
     * @param name   the name of the property to be set.
     * @param values an array of <code>Value</code> objects.
     * @return the updated <code>Property</code> object.
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is not multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          if another error occurs.
     */
    public Property setProperty(String name, String[] values) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified array of values and to the specified type.
     * Same as {@link #setProperty(String name, Value[] values, int type)}
     * except that the values are specified as <code>String</code>
     * objects instead of <code>Value</code> objects.
     *
     * @param name the name of the property to be set.
     * @param values an array of <code>Value</code> objects.
     * @param type the type of the property.
     * @return the updated <code>Property</code> object.
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the specified type
     * or if the property already exists and is not multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public Property setProperty(String name, String[] values, int type) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.STRING</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.STRING</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.STRING</code>.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (String)null)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, String value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified (single-value) property to the specified value.
     * If the property does not yet exist, it is created.
     * <p/>
     * The type of the property is determined by the <code>type</code> parameter specified.
     * <p/>
     * If the property type specified is not <code>PropertyType.STRING</code>,
     * then a best-effort conversion is attempted. If the conversion fails, a
     * <code>ValueFormatException</code> is thrown.
     * <p/>
     * If the property is not single-valued then a <code>ValueFormatException</code> is also thrown.
     * <p/>
     * If the property already exists it assumes both the new value and the new property type.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Value)null, type)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name the name of the property to be set.
     * @param value a <code>String</code> object.
     * @param type the type of the property.
     *
     * @return the <code>Property</code> object set, or <code>null</code>
     * if this method was used to remove a property (by setting its value to <code>null</code>).
     *
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the specified type
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public Property setProperty(String name, String value, int type) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.BINARY</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.BINARY</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.BINARY</code>.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (InputStream)null)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, InputStream value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.BOOLEAN</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.BOOLEAN</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.BOOLEAN</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, boolean value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.DOUBLE</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.DOUBLE</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.DOUBLE</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, double value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.LONG</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.LONG</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.LONG</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, long value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified property to the specified value.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If this is something other than
     * <code>PropertyType.DATE</code>, a best-effort conversion is attempted.
     * If the conversion fails, a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.DATE</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.DATE</code>.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Calendar)null)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, Calendar value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the specified (<code>REFERENCE</code>)property
     * to refer to the specified <code>Node</code>.
     * If the property does not yet exist, it is created.
     * The property type of the property being set is determined
     * by the node type of <code>this</code> node (the one on which
     * this method is being called). If the property type of this property is
     * something other than either <code>PropertyType.REFERENCE</code> or undefined
     * then a <code>ValueFormatException</code> is
     * thrown. If the property is multi-valued, a <code>ValueFormatException</code> is
     * also thrown. If another error occurs, a <code>RepositoryException</code>
     * is thrown.
     * <p/>
     * If the node type of <code>this</code> node does not
     * specify a particular property type for the property being set
     * then <code>PropertyType.REFERENCE</code> is used and,
     * if the property already exists, it assumes both the new value
     * and type <code>PropertyType.REFERENCE</code>.
     * <p/>
     * Passing a <code>null</code> as the second parameter removes the property.
     * It is equivalent to calling <code>remove</code> on the <code>Property</code>
     * object itself. For example, <code>N.setProperty("P", (Node)null)</code>
     * would remove property called <code>"P"</code> of the node in <code>N</code>.
     * <p/>
     * To save the addition or removal of a property, a <code>save</code> call must be
     * performed that includes the parent of the property in its scope, that is,
     * a <code>save</code> on either the session, this node, or an ancestor of this node. To
     * save a change to an existing property, a <code>save</code> call that includes that
     * property in its scope is required. This means that in addition to the
     * above-mentioned <code>save</code> options, a <code>save</code> on the changed property
     * itself will also work.
     * <p/>
     * A <code>ConstraintViolationException</code> will
     * be thrown either immediately or on <code>save</code> if the change
     * would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its nearest versionable ancestor is
     * checked-in. Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately or on <code>save</code>
     * if a lock prevents the setting of the property. Implementations may differ on when this validation is performed.
     *
     * @param name  The name of a property of this node
     * @param value The value to assigned
     * @return The updated <code>Property</code> object
     * @throws ValueFormatException  if <code>value</code> cannot be converted to the type of the specified property
     * or if the property already exists and is multi-valued.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the property and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException          If another error occurs.
     */
    public Property setProperty(String name, Node value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Returns the node at <code>relPath</code> relative to this node.
     * <p/>
     * If <code>relPath</code> contains a path element that refers to a node with same-name sibling nodes without
     * explicitly including an index using the array-style notation (<code>[x]</code>), then the index [1] is assumed
     * (indexing of same name siblings begins at 1, not 0, in order to preserve compatibility with XPath).
     * <p/>
     * Within the scope of a single <code>Session</code> object, if a <code>Node</code> object has been acquired,
     * any subsequent call of getNode reacquiring the same node must return a <code>Node</code> object reflecting
     * the same state as the earlier <code>Node</code> object. Whether this object is actually the same <code>Node</code>
     * instance, or simply one wrapping the same state, is up to the implementation.
     *
     * @param relPath The relative path of the node to retrieve.
     * @return The node at <code>relPath</code>.
     * @throws PathNotFoundException If no node exists at the
     *                               specified path.
     * @throws RepositoryException   If another error occurs.
     */
    public Node getNode(String relPath) throws PathNotFoundException, RepositoryException;

    /**
     * Returns a <code>NodeIterator</code> over all child <code>Node</code>s of
     * this <code>Node</code>. Does <i>not</i> include properties of this
     * <code>Node</code>. The same reacquisition
     * semantics apply as with {@link #getNode(String)}.
     * If this node has no child nodes, then an empty iterator is returned.
     *
     * @return A <code>NodeIterator</code> over all child <code>Node</code>s of
     *         this <code>Node</code>.
     * @throws RepositoryException If an error occurs.
     */
    public NodeIterator getNodes() throws RepositoryException;

    /**
     * Gets all child nodes of this node that match <code>namePattern</code>.
     * The pattern may be a full name or a partial name with one or more
     * wildcard characters ("<code>*</code>"), or a disjunction (using the
     * "<code>|</code>" character to represent logical <code>OR</code>) of
     * these. For example,
     * <p/>
     * <code>N.getNodes("jcr:* | myapp:report | my doc")</code>
     * <p/>
     * would return a <code>NodeIterator</code> holding all child nodes of
     * <code>N</code> that are either called '<code>myapp:report</code>', begin
     * with the prefix '<code>jcr:</code>' or are called '<code>my doc</code>'.
     * <p/>
     * Note that leading and trailing whitespace around a disjunct is ignored,
     * but whitespace within a disjunct forms part of the pattern to be matched.
     * <p/>
     * The EBNF for <code>namePattern</code> is:
     * <p/>
     * <code>
     * namePattern ::= disjunct {'|' disjunct}<br>
     * disjunct ::= name [':' name]<br>
     * name ::= '*' | ['*'] fragment {'*' fragment} ['*']<br>
     * fragment ::= char {char}<br>
     * char ::= nonspace | ' '<br>
     * nonspace ::= (* Any Unicode character except: '/', ':', '[', ']', '*', ''', '"', '|'
     * or any whitespace character *)
     * </code>
     * <p/>
     * The pattern is matched against the names (not the paths)
     * of the immediate child nodes of this node.
     * <p/>
     * If this node has no matching child nodes, then an empty iterator is returned.
     * <p/>
     * The same reacquisition
     * semantics apply as with <code>{@link #getNode(String)}</code>.
     *
     * @param namePattern a name pattern
     * @return a <code>NodeIterator</code>
     * @throws RepositoryException If an unexpected error occurs.
     */
    public NodeIterator getNodes(String namePattern) throws RepositoryException;

    /**
     * Returns the property at <code>relPath</code> relative to <code>this</code>
     * node. The same reacquisition
     * semantics apply as with <code>{@link #getNode(String)}</code>.
     *
     * @param relPath The relative path of the property to retrieve.
     * @return The property at <code>relPath</code>.
     * @throws PathNotFoundException If no property exists at the
     *                               specified path.
     * @throws RepositoryException   If another error occurs.
     */
    public Property getProperty(String relPath) throws PathNotFoundException, RepositoryException;

    /**
     * Returns all properties of this node.
     * Returns a <code>PropertyIterator</code> over all properties
     * of this node. Does <i>not</i> include child <i>nodes</i> of this
     * node. The same reacquisition
     * semantics apply as with <code>{@link #getNode(String)}</code>.
     * If this node has no properties, then an empty iterator is returned.
     *
     * @return A <code>PropertyIterator</code>.
     * @throws RepositoryException If an error occurs.
     */
    public PropertyIterator getProperties() throws RepositoryException;

    /**
     * Gets all properties of this node that match <code>namePattern</code>.
     * The pattern may be a full name or a partial name with one or more
     * wildcard characters ("<code>*</code>"), or a disjunction (using the
     * "<code>|</code>" character to represent logical <code>OR</code>) of
     * these. For example,
     * <p/>
     * <code>N.getProperties("jcr:* | myapp:name | my doc")</code>
     * <p/>
     * would return a <code>PropertyIterator</code> holding all properties of
     * <code>N</code> that are either called '<code>myapp:name</code>', begin
     * with the prefix '<code>jcr:</code>' or are called '<code>my doc</code>'.
     * <p/>
     * Note that leading and trailing whitespace around a disjunct is ignored,
     * but whitespace within a disjunct forms part of the pattern to be matched.
     * <p/>
     * The EBNF for <code>namePattern</code> is:
     * <p/>
     * <code>
     * namePattern ::= disjunct {'|' disjunct}<br>
     * disjunct ::= name [':' name]<br>
     * name ::= '*' | ['*'] fragment {'*' fragment} ['*']<br>
     * fragment ::= char {char}<br>
     * char ::= nonspace | ' '<br>
     * nonspace ::= (* Any Unicode character except: '/', ':', '[', ']', '*', ''', '"', '|'
     * or any whitespace character *)
     * </code>
     * <p/>
     * The pattern is matched against the names (not the paths)
     * of the immediate child properties of this node.
     * <p/>
     * If this node has no matching properties, then an empty iterator is returned.
     * <p/>
     * The same reacquisition
     * semantics apply as with <code>{@link #getNode(String)}</code>.
     *
     * @param namePattern a name pattern
     * @return a <code>PropertyIterator</code>
     * @throws RepositoryException If an unexpected error occurs.
     */
    public PropertyIterator getProperties(String namePattern) throws RepositoryException;

    /**
     * Returns the primary child item of this node.
     * The primary node type of this node may specify one child item (child node or property)
     * of this node as the <i>primary child item</i>.
     * This method returns that item. If this node does not have a primary item,
     * either because none is declared in the node type or
     * because a declared primary item is not present on this node instance,
     * then this method throws an <code>ItemNotFoundException</code>.
     * The same reacquisition semantics apply as with <code>{@link #getNode(String)}</code>.
     *
     * @return the primary child item.
     * @throws ItemNotFoundException if this node does not have a primary
     * child item, either because none is declared in the node type or
     * because a declared primary item is not present on this node instance.
     * @throws RepositoryException if another error occurs.
     */
    public Item getPrimaryItem() throws ItemNotFoundException, RepositoryException;

    /**
     * Returns the UUID of this node as recorded in this node's <code>jcr:uuid</code>
     * property. This method only works on nodes of mixin node type
     * <code>mix:referenceable</code>. On nonreferenceable nodes, this method
     * throws an <code>UnsupportedRepositoryOperationException</code>. To avoid throwing an exception
     * to determine whether a node has a UUID, a call to {@link #isNodeType(String) isNodeType("mix:referenceable")}
     * can be made.
     *
     * @return the UUID of this node
     * @throws UnsupportedRepositoryOperationException
     *                             If this node nonreferenceable.
     * @throws RepositoryException If another error occurs.
     */
    public String getUUID() throws UnsupportedRepositoryOperationException, RepositoryException;

    /**
     * This method returns the index of this node within the ordered set of its same-name
     * sibling nodes. This index is the one used to address same-name siblings using the
     * square-bracket notation, e.g., <code>/a[3]/b[4]</code>. Note that the index always starts
     * at 1 (not 0), for compatibility with XPath. As a result, for nodes that do not have
     * same-name-siblings, this method will always return 1.
     *
     * @return The index of this node within the ordered set of its same-name sibling nodes.
     * @throws RepositoryException if an error occurs.
     */
    public int getIndex() throws RepositoryException;

    /**
     * Returns all <code>REFERENCE</code> properties that refer to this node.
     * <p/>
     * Some level 2 implementations may only return properties that have been
     * saved (in a transactional setting this includes both those properties
     * that have been saved but not yet committed, as well as properties that
     * have been committed). Other level 2 implementations may additionally
     * return properties that have been added within the current
     * <code>Session</code> but are not yet saved.
     * <p/>
     * In implementations that support versioing, this method does not return
     * <code>REFERENCE</code> propertiesthat are part of the frozen state of a
     * version in version storage.
     * <p/>
     * If this node has no references, an empty iterator is returned.
     *
     * @return A <code>PropertyIterator</code>.
     * @throws RepositoryException if an error occurs
     */
    public PropertyIterator getReferences() throws RepositoryException;

    /**
     * Indicates whether a node exists at <code>relPath</code>
     * Returns <code>true</code> if a node exists at <code>relPath</code> and
     * <code>false</code> otherwise.
     *
     * @param relPath The path of a (possible) node.
     * @return <code>true</code> if a node exists at <code>relPath</code>;
     *         <code>false</code> otherwise.
     * @throws RepositoryException If an unspecified error occurs.
     */
    public boolean hasNode(String relPath) throws RepositoryException;

    /**
     * Indicates whether a property exists at <code>relPath</code>
     * Returns <code>true</code> if a property exists at <code>relPath</code> and
     * <code>false</code> otherwise.
     *
     * @param relPath The path of a (possible) property.
     * @return <code>true</code> if a property exists at <code>relPath</code>;
     *         <code>false</code> otherwise.
     * @throws RepositoryException If an unspecified error occurs.
     */
    public boolean hasProperty(String relPath) throws RepositoryException;

    /**
     * Indicates whether this node has child nodes.
     * Returns <code>true</code> if this node has one or more child nodes;
     * <code>false</code> otherwise.
     *
     * @return <code>true</code> if this node has one or more child nodes;
     *         <code>false</code> otherwise.
     * @throws RepositoryException If an unspecified error occurs.
     */
    public boolean hasNodes() throws RepositoryException;

    /**
     * Indicates whether this node has properties.
     * Returns <code>true</code> if this node has one or more properties;
     * <code>false</code> otherwise.
     *
     * @return <code>true</code> if this node has one or more properties;
     *         <code>false</code> otherwise.
     * @throws RepositoryException If an unspecified error occurs.
     */
    public boolean hasProperties() throws RepositoryException;

    /**
     * Returns the primary node type of this node. Which node type is returned when this method is called on the root
     * node of a workspace is up to the implementation, though the returned type must, of course, be
     * consistent with ther child nodes and properties of the root node.
     *
     * @return a <code>NodeType</code> object.
     * @throws RepositoryException if an error occurs
     */
    public NodeType getPrimaryNodeType() throws RepositoryException;

    /**
     * Returns an array of NodeType objects representing the mixin node types
     * assigned to this node. This includes only those mixin types explicitly
     * assigned to this node, and therefore listed in the property
     * <code>jcr:mixinTypes</code>. It does not include mixin types inherited
     * through the additon of supertypes to the primary type hierarchy.
     *
     * @return an array of  <code>NodeType</code> objects.
     * @throws RepositoryException if an error occurs
     */
    public NodeType[] getMixinNodeTypes() throws RepositoryException;

    /**
     * Indicates whether this node is of the specified node type.
     * Returns <code>true</code> if this node is of the specified node type
     * or a subtype of the specified node type. Returns <code>false</code> otherwise.
     *
     * @param nodeTypeName the name of a node type.
     * @return true if this node is of the specified node type
     *         or a subtype of the specified node type; returns false otherwise.
     * @throws RepositoryException If an error occurs.
     */
    public boolean isNodeType(String nodeTypeName) throws RepositoryException;

    /**
     * Adds the specified mixin node type to this node.
     * Also adds <code>mixinName</code> to this node's <code>jcr:mixinTypes</code>
     * property immediately. Semantically, the mixin node type assignment may take
     * effect immediately and at the very least, it must take effect on <code>save</code>.
     * <p/>
     * A <code>ConstraintViolationException</code> is thrown either immediately or on <code>save</code>
     * if a conflict with another assigned mixin or the primary node type or for an implementation-specific
     * reason. Implementations may differ on when this validation is done.
     * <p/>
     * In some implementations it may only be possible to add mixin types before a
     * a node is first saved, and not after. I such cases any later calls to
     * <code>addMixin</code> will throw a <code>ConstraintViolationException</code>
     * either immediately or on <code>save</code>.
     * <p/>
     * A <code>NoSuchNodeTypeException</code> is thrown either immediately or on <code>save</code>
     * if the specified <code>mixinName</code> is not recognized.
     * Implementations may differ on when this validation is done.
     * <p/>
     * A <code>VersionException</code> is thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in.
     * Implementations may differ on when this validation is done.
     * <p/>
     * A <code>LockException</code> is thrown either immediately or on <code>save</code>
     * if a lock prevents the addition of the mixin.
     * Implementations may differ on when this validation is done.
     *
     * @param mixinName the name of the mixin node type to be added
     * @throws NoSuchNodeTypeException If the specified <code>mixinName</code>
     * is not recognized and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException If the specified mixin node type
     * is prevented from being assigned.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     * nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>..
     * @throws LockException if a lock prevents the addition of the mixin and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException  if another error occurs.
     */
    public void addMixin(String mixinName) throws NoSuchNodeTypeException, VersionException, ConstraintViolationException, LockException, RepositoryException;

    /**
     * Removes the specified mixin node type from this node. Also removes <code>mixinName</code>
     * from this node's <code>jcr:mixinTypes</code> property immediately. Semantically, the mixin
     * node type removal may take effect immediately and at the very least, it must
     * take effect on <code>save</code>.
     * <p/>
     * If this node does not have the specified mixin, a <code>NoSuchNodeTypeException</code> is thrown
     * either immediately or on <code>save</code>. Implementations may differ on when this validation is done.
     * <p/>
     * A <code>ConstraintViolationException</code> will be thrown either immediately or on <code>save</code>
     * if the removal of a mixin is not allowed. Implementations are free to enforce any policy they
     * like with regard to mixin removal and may differ on when this validation is done.
     * <p/>
     * A <code>VersionException</code> is thrown either immediately or on <code>save</code>
     * if this node is versionable and checked-in or is
     * non-versionable but its nearest versionable ancestor is checked-in.
     * Implementations may differ on when this validation is done.
     * <p/>
     * A <code>LockException</code> is thrown either immediately or on <code>save</code>
     * if a lock prevents the removal of the mixin.
     * Implementations may differ on when this validation is done.
     *
     * @param mixinName the name of the mixin node type to be removed.
     * @throws NoSuchNodeTypeException if the specified <code>mixinName</code>
     * is not currently assigned to this node and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the specified mixin node type
     * is prevented from being removed and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws VersionException if this node is versionable and checked-in or is non-versionable but its
     *  nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the removal of the mixin and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>..
     * @throws RepositoryException if another error occurs.
     */
    public void removeMixin(String mixinName) throws NoSuchNodeTypeException, VersionException, ConstraintViolationException, LockException, RepositoryException;

    /**
     * Returns <code>true</code> if the specified mixin node type, <code>mixinName</code>,
     * can be added to this node. Returns <code>false</code> otherwise. A result of
     * <code>false</code> must be returned in each of the following cases:
     * <ul>
     * <li>
     * The mixin's definition conflicts with an existing primary or mixin node type of this node.
     * </li>
     * <li>
     * This node is versionable and checked-in or is non-versionable and its nearest versionable
     * ancestor is checked-in.
     * </li>
     * <li>
     * This node is protected (as defined in this node's <code>NodeDefinition</code>,
     * found in the node type of this node's parent).
     * </li>
     * <li>
     * An access control restriction would prevent the addition of the mixin.
     * </li>
     * <li>
     * A lock would prevent the addition of the mixin.
     * </li>
     * <li>
     * An implementation-specific restriction would prevent the addition of the mixin.
     * </li>
     * </ul>
     * A <code>NoSuchNodeTypeException</code> is thrown if the specified mixin node type name is not recognized.
     *
     * @param mixinName The name of the mixin to be tested.
     * @return <code>true</code> if the specified mixin node type,
     *         <code>mixinName</code>, can be added to this node; <code>false</code> otherwise.
     * @throws NoSuchNodeTypeException if the specified mixin node type name is not recognized.
     * @throws RepositoryException if another error occurs.
     */
    public boolean canAddMixin(String mixinName) throws NoSuchNodeTypeException, RepositoryException;

    /**
     * Returns the node definition that applies to this node. In some cases there may appear
     * to be more than one definition that could apply to this node. However, it is assumed that upon
     * creation of this node, a single particular definition was used and it is <i>that</i> definition that
     * this method returns. How this governing definition is selected upon node creation from among others
     * which may have been applicable is an implementation issue and is not covered by this specification.
     * The <code>NodeDefinition</code> returned when this method is called on the root node of a workspace
     * is also up to the implementation.
     *
     * @return a <code>NodeDefinition</code> object.
     * @throws RepositoryException if an error occurs.
     * @see NodeType#getChildNodeDefinitions
     */
    public NodeDefinition getDefinition() throws RepositoryException;

    /**
     * Creates a new version with a system generated version name and returns that version
     * (which will be the new base version of this node). Sets the <code>jcr:checkedOut</code>
     * property to false thus putting the node into the <i>checked-in</i> state. This means
     * that this node and its <i>connected non-versionable subtree</i> become read-only.
     * A node's connected non-versionable subtree is the set of non-versionable descendant nodes
     * reachable from that node through child links without encountering any versionable nodes.
     * In other words, the read-only status flows down from the checked-in node along every child
     * link until either a versionable node is encountered or an item with no children is encountered.
     * <p/>
     * Read-only status means that an item cannot be altered by the client using standard API methods
     * (addNode, setProperty, etc.). The only exceptions to this rule are the {@link Node#restore}
     * (all signatures), {@link Workspace#restore}, {@link Node#merge} and {@link Node#update}
     * operations; these do not respect read-only status due to check-in. Note that <code>remove</code>
     * of a read-only node is possible, as long as its parent is not read-only (since removal is an
     * alteration of the parent node).
     * <p/>
     * If this node is already checked-in, this method has no effect but returns the current base version
     * of this node.
     * <p/>
     * If this node is not versionable, an <code>UnsupportedRepositoryOperationException</code> is thrown.
     * <p/>
     * A <code>VersionException</code> is thrown or if a child item of this node has an
     * <code>OnParentVersion</code> status of <code>ABORT</code>. This includes the case where
     * an unresolved merge failure exists on this node, as indicated by the presence of the
     * <code>jcr:mergeFailed</code> property.
     * <p/>
     * If there are unsaved changes pending on this node, an <code>InvalidItemStateException</code>
     * is thrown.
     * <p/>
     * Throws a <code>LockException</code> if a lock prevents the checkin.
     * <p/>
     * If <code>checkin</code> succeeds, the change to the <code>jcr:checkedOut</code> property is
     * automatically saved (there is no need to do an additional <code>save</code>).
     * <p/>
     *
     * @return a <code>Version</code> object
     * @throws VersionException          if jcr:predecessors does not contain at least one value or if
     *                                   a child item of this node has an <code>OnParentVersion</code> status of <code>ABORT</code>.
     *                                   This includes the case where an unresolved merge failure exists on this node, as indicated
     *                                   by the presence of a <code>jcr:mergeFailed</code> property.
     * @throws UnsupportedRepositoryOperationException
     *                                   If this node is not versionable.
     * @throws InvalidItemStateException If unsaved changes exist on this node.
     * @throws LockException             if a lock prevents the checkin.
     * @throws RepositoryException       If another error occurs.
     */
    public Version checkin() throws VersionException, UnsupportedRepositoryOperationException, InvalidItemStateException, LockException, RepositoryException;

    /**
     * Sets this versionable node to checked-out status by setting its
     * <code>jcr:isCheckedOut</code> property to true and adds to the
     * <code>jcr:predecessors</code> (multi-value) property a reference to the current
     * base version (the same value as held in <code>jcr:baseVersion</code>).
     * This method puts the node into the <i>checked-out</i> state, making it and its
     * connected non-versionable subtree no longer
     * read-only (see {@link #checkin} for an explanation of the term
     * "connected non-versionable subtree").
     * <p/>
     * If successful, these changes are persisted immediately,
     * there is no need to call <code>save</code>.
     * <p/>
     * If this node is already checked-out, this method has no effect.
     * </p>
     * If this node is not versionable, an <code>UnsupportedRepositoryOperationException</code> is thrown.
     * <p/>
     * Throws a <code>LockException</code> if a lock prevents the checkout.
     *
     * @throws UnsupportedRepositoryOperationException
     *                             If this node is not versionable.
     * @throws LockException       if a lock prevents the checkout.
     * @throws RepositoryException If another error occurs.
     */
    public void checkout() throws UnsupportedRepositoryOperationException, LockException, RepositoryException;

    /**
     * Completes the merge process with respect to this node and the specified <code>version</code>.
     * <p/>
     * When the {@link #merge} method is called on a node, every versionable node in that
     * subtree is compared with its corresponding node in the indicated other workspace and
     * a "merge test result" is determined indicating one of the following:
     * <ol>
     * <li>
     * This node will be updated to the state of its correspondee (if the base version
     * of the correspondee is more recent in terms of version history)
     * </li>
     * <li>
     * This node will be left alone (if this node's base version is more recent in terms of
     * version history).
     * </li>
     * <li>
     * This node will be marked as having failed the merge test (if this node's base version
     * is on a different branch of the version history from the base version of its
     * corresponding node in the other workspace, thus preventing an automatic determination
     * of which is more recent).
     * </li>
     * </ol>
     * (See {@link #merge} for more details)
     * <p/>
     * In the last case the merge of the non-versionable subtree
     * (the "content") of this node must be done by the application (for example, by
     * providing a merge tool for the user).
     * <p/>
     * Additionally, once the content of the nodes has been merged, their version graph
     * branches must also be merged. The JCR versioning system provides for this by
     * keeping a record, for each versionable node that fails the merge test, of the
     * base verison of the corresponding node that caused the merge failure. This record
     * is kept in the <code>jcr:mergeFailed</code> property of this node. After a
     * <code>merge</code>, this property will contain one or more (if
     * multiple merges have been performed) <code>REFERENCE</code>s that point
     * to the "offending versions".
     * <p/>
     * To complete the merge process, the client calls <code>doneMerge(Version v)</code>
     * passing the version object referred to be the <code>jcr:mergeFailed</code> property
     * that the client wishes to connect to <code>this</code> node in the version graph.
     * This has the effect of moving the reference to the indicated version from the
     * <code>jcr:mergeFailed</code> property of <code>this</code> node to the
     * <code>jcr:predecessors</code>.
     * <p/>
     * If the client chooses not to connect this node to a particular version referenced in
     * the <code>jcr:mergeFailed</code> property, he calls {@link #cancelMerge(Version version)}.
     * This has the effect of removing the reference to the specified <code>version</code> from
     * <code>jcr:mergeFailed</code> <i>without</i> adding it to <code>jcr:predecessors</code>.
     * <p/>
     * Once the last reference in <code>jcr:mergeFailed</code> has been either moved to
     * <code>jcr:predecessors</code> (with <code>doneMerge</code>) or just removed
     * from <code>jcr:mergeFailed</code> (with <code>cancelMerge</code>) the <code>jcr:mergeFailed</code>
     * property is automatically removed, thus enabling <code>this</code>
     * node to be checked-in, creating a new version (note that before the <code>jcr:mergeFailed</code>
     * is removed, its <code>OnParentVersion</code> setting of <code>ABORT</code> prevents checkin).
     * This new version will have a predecessor connection to each version for which <code>doneMerge</code>
     * was called, thus joining those branches of the version graph.
     * <p/>
     * If successful, these changes are persisted immediately,
     * there is no need to call <code>save</code>.
     * <p/>
     * A <code>VersionException</code> is thrown if the <code>version</code> specified is
     * not among those referecned in this node's <code>jcr:mergeFailed</code> property.
     * <p/>
     * If there are unsaved changes pending on this node, an <code>InvalidItemStateException</code> is thrown.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this node is not versionable.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param version a version referred to by this node's <code>jcr:mergeFailed</code> property.
     * @throws VersionException if the version specifed is not among those referenced in this node's <code>jcr:mergeFailed</code> or if this node is currently checked-in.
     * @throws InvalidItemStateException if there are unsaved changes pending on this node.
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws RepositoryException if another error occurs.
     */
    public void doneMerge(Version version) throws VersionException, InvalidItemStateException, UnsupportedRepositoryOperationException, RepositoryException;

    /**
     * Cancels the merge process with respect to this node and specified <code>version</code>.
     * <p/>
     * See {@link #doneMerge} for a full explanation. Also see {@link #merge} for
     * more details.
     * <p/>
     * If successful, these changes are persisted immediately,
     * there is no need to call <code>save</code>.
     * <p/>
     * A <code>VersionException</code> is thrown if the <code>version</code> specified is
     * not among those referecned in this node's <code>jcr:mergeFailed</code>.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this nod is not versionable.
     * <p/>
     * If there are unsaved changes pending on this node, an <code>InvalidItemStateException</code> is thrown.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param version a version referred to by this node's <code>jcr:mergeFailed</code> property.
     * @throws VersionException if the version specified is not among those referenced in this node's <code>jcr:mergeFailed</code> or if this node is currently checked-in.
     * @throws InvalidItemStateException if there are unsaved changes pending on this node.
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws RepositoryException if another error occurs.
     */
    public void cancelMerge(Version version) throws VersionException, InvalidItemStateException, UnsupportedRepositoryOperationException, RepositoryException;

    /**
     * If this node does have a corresponding node in the workspace <code>srcWorkspaceName</code>,
     * then this replaces this node and its subtree with a clone of the corresponding node and its
     * subtree.
     * <p/>
     * If this node does not have a corresponding node in the workspace
     * <code>srcWorkspaceName</code>, then the <code>update</code> method
     * has no effect.
     * <p/>
     * The <i>corresponding node</i> is defined as the node in <code>srcWorkspace</code>
     * with the same UUID as this node or, if this node has no UUID, the same
     * path relative to the nearest ancestor that <i>does</i>  have a UUID,
     * or the root node, whichever comes first. This is qualified by the requirment that
     * referencable nodes only correspond with other referencables and non-referenceables
     * with other non-referenceables.
     * <p/>
     * If the update succeeds the changes made are persisted immediately, there is
     * no need to call <code>save</code>.
     * <p/>
     * Note that <code>update</code> does not respect the checked-in status of nodes.
     * An <code>update</code> may change a node even if it is currently checked-in
     * (This fact is only relevant in an implementation that supports versioning).
     * <p/>
     * If the specified <code>srcWorkspace</code> does not exist, a
     * <code>NoSuchWorkspaceException</code> is thrown.
     * <p/>
     * If the current session does not have sufficient rights to perform the operation, then an
     * <code>AccessDeniedException</code> is thrown.
     * <p/>
     * An InvalidItemStateException is thrown if this <code>Session</code> (not necessarily this
     * <code>Node</code>) has pending unsaved changes.
     * <p/>
     * Throws a <code>LockException</code> if a lock prevents the update.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param srcWorkspaceName the name of the source workspace.
     * @throws NoSuchWorkspaceException  If <code>srcWorkspace</code> does not exist.
     * @throws InvalidItemStateException if this <code>Session</code> (not necessarily this <code>Node</code>) has pending unsaved changes.
     * @throws AccessDeniedException     If the current session does not have sufficient rights to perform the operation.
     * @throws LockException             if a lock prevents the update.
     * @throws RepositoryException       If another error occurs.
     */
    public void update(String srcWorkspaceName) throws NoSuchWorkspaceException, AccessDeniedException, LockException, InvalidItemStateException, RepositoryException;

    /**
     * This method can be thought of as a version-sensitive update (see 7.1.7
     * Updating and Cloning Nodes across Workspaces in the specification).
     * <p/>
     * It recursively tests each
     * versionable node in the subtree of this node against its corresponding
     * node in <code>srcWorkspace</code> with respect to the relation between their
     * respective base versions and either updates the node in question or not,
     * depending on the outcome of the test. For details see 8.2.10 Merge in the
     * specification.
     * A <code>MergeException</code> is thrown if <code>bestEffort</code> is false
     * and a versionable node is encountered whose corresponding node's base
     * version is on a divergent branch from this node's base version.
     * <p/>
     * If successful, the changes are persisted immediately, there is no need to
     * call <code>save</code>.
     * <p/>
     * This method returns a <code>NodeIterator</code> over all versionable nodes
     * in the subtree that received a merge result of fail.
     * <p/>
     * If <code>bestEffort</code> is false, this iterator will be empty
     * (since if it merge returns successfully, instead of throwing an exception,
     * it will be because no failures were encountered).
     * <p/>
     * If <code>bestEffort</code> is <code>true</code>, this iterator will
     * contain all nodes that received a fail during the course of this merge
     * operation.
     * <p/>
     * If the specified <code>srcWorkspace</code> does not exist, a
     * <code>NoSuchWorkspaceException</code> is thrown.
     * <p/>
     * If the current session does not have
     * sufficient permissions to perform the operation, then an
     * <code>AccessDeniedException</code> is thrown.
     * <p/>
     * An <code>InvalidItemStateException</code> is thrown
     * if this session (not necessarily this node) has pending unsaved changes.
     * <p/>
     * A <code>LockException</code> is thrown if a lock prevents the merge.
     *
     * @param srcWorkspace the name of the source workspace.
     * @param bestEffort a boolean
     * @return iterator over all nodes that received a merge result of "fail" in the course
     * of this operation.
     * @throws MergeException if <code>bestEffort</code> is <code>false</code> and a failed merge
     * result is encountered.
     * @throws InvalidItemStateException if this session (not necessarily this
     * node) has pending unsaved changes.
     * @throws NoSuchWorkspaceException if <code>srcWorkspace</code> does not exist.
     * @throws AccessDeniedException if the current session does not have sufficient
     * rights to perform the operation.
     * @throws LockException if a lock prevents the merge.
     * @throws RepositoryException if another error occurs.
     */
    public NodeIterator merge(String srcWorkspace, boolean bestEffort) throws NoSuchWorkspaceException, AccessDeniedException, MergeException, LockException, InvalidItemStateException, RepositoryException;

    /**
     * Returns the absolute path of the node in the specified workspace that
     * corresponds to <code>this</code> node.
     * <p/>
     * The <i>corresponding node</i> is defined as the node in <code>srcWorkspace</code>
     * with the same UUID as this node or, if this node has no UUID, the same
     * path relative to the nearest ancestor that <i>does</i>  have a UUID,
     * or the root node, whichever comes first. This is qualified by the requirement that
     * referencable nodes only correspond with other referencables and non-referenceables
     * with other non-referenceables.
     * <p/>
     * If no corresponding node exists then an <code>ItemNotFoundException</code> is thrown.
     * <p/>
     * If the specified workspace does not exist then a <code>NoSuchWorkspaceException</code> is thrown.
     * <p/>
     * If the current <code>Session</code> does not have sufficent rights to perform this operation,
     * an <code>AccessDeniedException</code> is thrown.
     *
     * @param workspaceName
     * @return the absolute path to the corresponding node.
     * @throws ItemNotFoundException    if no corresponding node is found.
     * @throws NoSuchWorkspaceException if the workspace is unknown.
     * @throws AccessDeniedException    if the current <code>session</code> has insufficent rights to perform this operation.
     * @throws RepositoryException      if another error occurs.
     */
    public String getCorrespondingNodePath(String workspaceName) throws ItemNotFoundException, NoSuchWorkspaceException, AccessDeniedException, RepositoryException;

    /**
     * Returns true if this node is either
     * <ul>
     * <li/>versionable and currently checked-out,
     * <li/>non-versionable and its nearest versionable ancestor is checked-out or
     * <li/>non-versionable and it has no versionable ancestor.
     * </ul>
     * Returns false if this node is either
     * <ul>
     * <li/>versionable and currently checked-in or
     * <li/>non-versionable and its nearest versionable ancestor is checked-in.
     * </ul>
     *
     * @return a boolean
     * @throws RepositoryException If another error occurs.
     */
    public boolean isCheckedOut() throws RepositoryException;

    /**
     * Restores <code>this</code> node to the state defined by the
     * version with the specified <code>versionName</code>.
     * <p/>
     * If this node is not versionable, an
     * <code>UnsupportedRepositoryOperationException</code> is thrown.
     * <p/>
     * If successful, the change is persisted immediately and there is no
     * need to call <code>save</code>.
     * <p/>
     * A <code>VersionException</code> is thrown if no version with the specified <code>versionName</code>
     * exists in this node's version history or if an attempt is made to restore the root version
     * (<code>jcr:rootVersion</code>).
     * <p/>
     * An InvalidItemStateException is thrown if this <code>Session</code> (not necessarily this
     * <code>Node</code>) has pending unsaved changes.
     * <p/>
     * A LockException is thrown if a lock prevents the addition of the mixin.
     * <p/>
     * This method will work regardless of whether this node is checked-in or not.
     * <p/>
     * A UUID collision occurs when a node exists <i>outside the subtree rooted at this node</i>
     * with the same UUID as a node that would be introduced by the <code>restore</code>
     * operation <i>into the subtree at this node</i>. The result in such a case is governed by
     * the <code>removeExisting</code> flag. If <code>removeExisting</code> is <code>true</code>,
     * then the incoming node takes precedence, and the existing node (and its subtree) is removed.
     * If <code>removeExisting</code> is <code>false</code>, then a <code>ItemExistsException</code>
     * is thrown and no changes are made. Note that this applies not only to cases where the restored
     * node itself conflicts with an existing node but also to cases where a conflict occurs with any
     * node that would be introduced into the workspace by the restore operation. In particular, conflicts
     * involving subnodes of the restored node that have <code>OnParentVersion</code> settings of
     * <code>COPY</code> or <code>VERSION</code> are also governed by the <code>removeExisting</code> flag.
     *
     * @param versionName    a <code>Version</code> object
     * @param removeExisting a boolean flag that governs what happens in case of a UUID collision.
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws VersionException if the specified <code>version</code> is not part of this node's version history
     * or if an attempt is made to restore the root version (<code>jcr:rootVersion</code>).
     * @throws ItemExistsException       if <code>removeExisting</code> is <code>false</code> and a UUID collision occurs.
     * @throws LockException             if a lock prevents the restore.
     * @throws InvalidItemStateException if this <code>Session</code> (not necessarily this <code>Node</code>) has pending unsaved changes.
     * @throws RepositoryException       If another error occurs.
     */
    public void restore(String versionName, boolean removeExisting) throws VersionException, ItemExistsException, UnsupportedRepositoryOperationException, LockException, InvalidItemStateException, RepositoryException;

    /**
     * Restores <code>this</code> node to the state defined by the specified
     * <code>version</code>.
     * <p/>
     * If this node is not versionable, an
     * <code>UnsupportedRepositoryOperationException</code> is thrown.
     * <p/>
     * If successful, the change is persisted immediately and there is no
     * need to call <code>save</code>.
     * <p/>
     * A <code>VersionException</code> is thrown if the specified <code>version</code>
     * is not part of this node's version history or if an attempt is made to restore the root version (<code>jcr:rootVersion</code>).
     * <p/>
     * An InvalidItemStateException is thrown if this <code>Session</code> (not necessarily this
     * <code>Node</code>) has pending unsaved changes.
     * <p/>
     * A <code>LockException</code> is thrown if a lock prevents the restore.
     * <p/>
     * This method will work regardless of whether this node is checked-in or not.
     * <p/>
     * A UUID collision occurs when a node exists <i>outside the subtree rooted at this node</i>
     * with the same UUID as a node that would be introduced by the <code>restore</code>
     * operation <i>into the subtree at this node</i>. The result in such a case is governed by
     * the <code>removeExisting</code> flag. If <code>removeExisting</code> is <code>true</code>,
     * then the incoming node takes precedence, and the existing node (and its subtree) is removed.
     * If <code>removeExisting</code> is <code>false</code>, then a <code>ItemExistsException</code>
     * is thrown and no changes are made. Note that this applies not only to cases where the restored
     * node itself conflicts with an existing node but also to cases where a conflict occurs with any
     * node that would be introduced into the workspace by the restore operation. In particular, conflicts
     * involving subnodes of the restored node that have <code>OnParentVersion</code> settings of
     * <code>COPY</code> or <code>VERSION</code> are also governed by the <code>removeExisting</code> flag.
     *
     * @param version a <code>Version</code> object
     * @param removeExisting a boolean flag that governs what happens in case of a UUID collision.
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws VersionException if the specified <code>version</code> is not part of this node's version history
     * or if an attempt is made to restore the root version (<code>jcr:rootVersion</code>).
     * @throws ItemExistsException if <code>removeExisting</code> is <code>false</code> and a UUID collision occurs.
     * @throws InvalidItemStateException if this <code>Session</code> (not necessarily this <code>Node</code>)
     * has pending unsaved changes.
     * @throws LockException if a lock prevents the restore.
     * @throws RepositoryException if another error occurs.
     */
    public void restore(Version version, boolean removeExisting) throws VersionException, ItemExistsException, UnsupportedRepositoryOperationException, LockException, RepositoryException;

    /**
     * Restores the specified version to <code>relPath</code>, relative to this node.
     * <p/>
     * A node need not exist at relPath, though the parent of <code>relPath</code>
     * must exist, otherwise a <code>PathNotFoundException</code> is thrown.
     * <p/>
     * If a node <i>does</i> exist at relPath then it must correspond to the version being restored
     * (the version must be a version <i>of that node</i>) and must not be a root version
     * (<code>jcr:rootVersion</code>), otherwise a <code>VersionException</code>
     * is thrown.
     * <p/>
     * If no node exists at <code>relPath</code> then a <code>VersionException</code> is thrown if
     * the parent node of <code>relPath</code> is versionable and checked-in or is non-versionable but
     * its nearest versionable ancestor is checked-in.
     * <p/>
     * If there <i>is</i> a node at <code>relPath</code> then the checked-in status of that node
     * itself and the checked-in status of its parent are irrelevant. The restore will work even if
     * one or both are checked-in.
     * <p/>
     * A UUID collision occurs when a node exists <i>outside the subtree rooted at <code>relPath</code></i>
     * with the same UUID as a node that would be introduced by the <code>restore</code> operation
     * <i>into the subtree at <code>relPath</code></i> (Note that in cases where there is no node at
     * <code>relPath</code>, this amounts to saying that a UUID collsion occurs if there exists
     * a node <i>anywhere</i> in this workspace with the same UUID as a node that would be introduced by
     * the <code>restore</code>). The result in such a case is governed by the <code>removeExisting</code>
     * flag. If <code>removeExisting</code> is <code>true</code>, then the incoming node takes precedence,
     * and the existing node (and its subtree) is removed. If <code>removeExisting</code> is
     * <code>false</code>, then a <code>ItemExistsException</code> is thrown and no changes are made.
     * Note that this applies not only to cases where the restored
     * node itself conflicts with an existing node but also to cases where a conflict occurs with any
     * node that would be introduced into the workspace by the restore operation. In particular, conflicts
     * involving subnodes of the restored node that have <code>OnParentVersion</code> settings of
     * <code>COPY</code> or <code>VERSION</code> are also governed by the <code>removeExisting</code> flag.
     * <p/>
     * If the would-be parent of the location <code>relPath</code> is actually a property, or if a node type
     * restriction would be violated, then a <code>ConstraintViolationException</code> is thrown.
     * <p/>
     * If the <code>restore</code> succeeds, the changes made to this node are persisted
     * immediately, there is no need to call <code>save</code>.
     * <p/>
     * An InvalidItemStateException is thrown if this <code>Session</code> (not necessarily this
     * <code>Node</code>) has pending unsaved changes.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this node is not versionable.
     * <p/>
     * A <code>LockException</code> is thrown if a lock prevents the restore.
     *
     * @param version a version object
     * @param relPath the path to which the version is to be restored
     * @param removeExisting overns what happens on UUID collision.
     * @throws PathNotFoundException if the parent of <code>relPath</code> does not exist.
     * @throws ItemExistsException if removeExisting is false and a UUID collision occurs
     * @throws ConstraintViolationException If the would-be parent of the location <code>relPath</code> is
     * actually a property, or if a node type restriction would be violated
     * @throws VersionException if the parent node of <code>relPath</code> is versionable and checked-in or is
     * non-versionable but its nearest versionable ancestor is checked-in or if a node exists at relPath that is not
     * the node corresponding to the specified <code>version</code> or if an attempt is made to restore the root version
     * (<code>jcr:rootVersion</code>).
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws LockException if a lock prevents the restore.
     * @throws InvalidItemStateException if this <code>Session</code> (not necessarily this <code>Node</code>) has pending unsaved changes.
     * @throws RepositoryException if another error occurs
     */
    public void restore(Version version, String relPath, boolean removeExisting) throws PathNotFoundException, ItemExistsException, VersionException, ConstraintViolationException, UnsupportedRepositoryOperationException, LockException, InvalidItemStateException, RepositoryException;

    /**
     * Restores the version of this node with the specified version label.
     * If this node is not versionable, an
     * <code>UnsupportedRepositoryOperationException</code> is thrown.
     * If successful, the change is persisted immediately and there is no
     * need to call <code>save</code>.
     * <p/>
     * A <code>VersionException</code> is thrown if the specified <code>versionLabel</code>
     * does not exist in this node's version history.
     * <p/>
     * An InvalidItemStateException is thrown if this <code>Session</code> (not necessarily this
     * <code>Node</code>) has pending unsaved changes.
     * <p/>
     * A <code>LockException</code> is thrown if a lock prevents the restore.
     * <p/>
     * This method will work regardless of whether this node is checked-in or not.
     * <p/>
     * A UUID collision occurs when a node exists <i>outside the subtree rooted at this node</i>
     * with the same UUID as a node that would be introduced by the <code>restoreByLabel</code>
     * operation <i>into the subtree at this node</i>. The result in such a case is governed by
     * the <code>removeExisting</code> flag. If <code>removeExisting</code> is <code>true</code>,
     * then the incoming node takes precedence, and the existing node (and its subtree) is removed.
     * If <code>removeExisting</code> is <code>false</code>, then a <code>ItemExistsException</code>
     * is thrown and no changes are made. Note that this applies not only to cases where the restored
     * node itself conflicts with an existing node but also to cases where a conflict occurs with any
     * node that would be introduced into the workspace by the restore operation. In particular, conflicts
     * involving subnodes of the restored node that have <code>OnParentVersion</code> settings of
     * <code>COPY</code> or <code>VERSION</code> are also governed by the <code>removeExisting</code> flag.
     *
     * @param versionLabel   a String
     * @param removeExisting a boolean flag that governs what happens in case of a UUID collision.
     * @throws UnsupportedRepositoryOperationException if this node is not verisonable.
     * @throws VersionException          if the specified <code>versionLabel</code>
     *                                   does not exist in this node's version history.
     * @throws ItemExistsException       if <code>removeExisting</code> is <code>false</code> and a UUID collision occurs.
     * @throws LockException             if a lock prevents the restore.
     * @throws InvalidItemStateException if this <code>Session</code> (not necessarily this <code>Node</code>) has pending unsaved changes.
     * @throws RepositoryException       If another error occurs.
     */
    public void restoreByLabel(String versionLabel, boolean removeExisting) throws VersionException, ItemExistsException, UnsupportedRepositoryOperationException, LockException, InvalidItemStateException, RepositoryException;

    /**
     * Returns the <code>VersionHistory</code> object of this node.
     * This object provides access to the <code>nt:versionHistory</code>
     * node holding this node's versions.
     * <p/>
     * If this node is not versionable, an <code>UnsupportedRepositoryOperationException</code> is thrown.
     *
     * @return a <code>VersionHistory</code> object
     * @throws UnsupportedRepositoryOperationException if this node is not versionable.
     * @throws RepositoryException If another error occurs.
     */
    public VersionHistory getVersionHistory() throws UnsupportedRepositoryOperationException, RepositoryException;

    /**
     * Returns the current base version of this versionable node.
     * <p/>
     * If this node is not versionable, an <code>UnsupportedRepositoryOperationException</code> is thrown.
     *
     * @return a <code>Version</code> object.
     * @throws UnsupportedRepositoryOperationException
     *                             if this node is not versionable.
     * @throws RepositoryException If another error occurs.
     */
    public Version getBaseVersion() throws UnsupportedRepositoryOperationException, RepositoryException;

    /**
     * Places a lock on this node. If successful, this node is said to <i>hold</i> the lock.
     * <p/>
     * If <code>isDeep</code> is <code>true</code> then the lock applies to this node and all its descendant nodes;
     * if <code>false</code>, the lock applies only to this, the holding node.
     * <p/>
     * If <code>isSessionScoped</code> is <code>true</code> then this lock will expire upon the expiration of the current
     * session (either through an automatic or explicit <code>Session.logout</code>); if <code>false</code>, this lock
     * does not expire until explicitly unlocked or automatically unlocked due to a implementation-specific limitation,
     * such as a timeout.
     * <p/>
     * Returns a <code>Lock</code> object reflecting the state of the new lock and including a lock token. See, in
     * contrast, {@link Node#getLock}, which returns the <code>Lock</code> <i>without</i> the lock token.
     * <p/>
     * The lock token is also automatically added to the set of lock tokens held by the current <code>Session</code>.
     * <p/>
     * If successful, then the property <code>jcr:lockOwner</code> is created and set to the value of
     * <code>Session.getUserID</code> for the current session and the property <code>jcr:lockIsDeep</code> is set to the
     * value passed in as <code>isDeep</code>. These changes are persisted automatically; there is no need to call
     * <code>save</code>.
     * <p/>
     * Note that it is possible to lock a node even if it is checked-in (the lock-related properties will be changed
     * despite the checked-in status).
     * <p/>
     * If this node is not of mixin node type <code>mix:lockable</code> then an
     * <code>LockException</code> is thrown.
     * <p/>
     * If this node is already locked (either because it holds a lock or a lock above it applies to it),
     * a <code>LockException</code> is thrown.
     * <p/>
     * If <code>isDeep</code> is <code>true</code> and a descendant node of this node already holds a lock, then a
     * <code>LockException</code> is thrown.
     * <p/>
     * If the current session does not have sufficient privileges to place the lock, an
     * <code>AccessDeniedException</code> is thrown.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this implementation does not support locking.
     * <p/>
     * An InvalidItemStateException is thrown if this node has pending unsaved changes.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param isDeep if <code>true</code> this lock will apply to this node and all its descendants; if
     * <code>false</code>, it applies only to this node.
     * @param isSessionScoped if <code>true</code>, this lock expires with the current session; if <code>false</code> it
     * expires when explicitly or automatically unlocked for some other reason.
     * @return A <code>Lock</code> object containing a lock token.
     * @throws UnsupportedRepositoryOperationException if this implementation does not support locking.
     * @throws LockException if this node is not <code>mix:lockable</code> or this node is already locked or
     * <code>isDeep</code> is <code>true</code> and a descendant node of this node already holds a lock.
     * @throws AccessDeniedException if this session does not have permission to lock this node.
     * @throws InvalidItemStateException if this node has pending unsaved changes.
     * @throws RepositoryException if another error occurs.
     */
    public Lock lock(boolean isDeep, boolean isSessionScoped) throws UnsupportedRepositoryOperationException, LockException, AccessDeniedException, InvalidItemStateException, RepositoryException;

    /**
     * Returns the <code>Lock</code> object that applies to this node. This may be either a lock on this node itself
     * or a deep lock on a node above this node.
     * <p/>
     * If this <code>Session</code> (the one through which this <code>Node</code> was acquired)
     * holds the lock token for this lock, then the returned <code>Lock</code> object contains
     * that lock token (accessible through <code>Lock.getLockToken</code>). If this <code>Session</code>
     * does not hold the applicable lock token, then the returned <code>Lock</code> object will not
     * contain the lock token (its <code>Lock.getLockToken</code> method will return <code>null</code>).
     * <p/>
     * If this node is not locked (no lock applies to this node), a <code>LockException</code> is thrown.
     * <p/>
     * If the current session does not have sufficient privileges to get the lock, an <code>AccessDeniedException</code>
     * is thrown.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this implementation does not support locking.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return The applicable <code>Lock</code> object, without a contained lock token.
     * @throws UnsupportedRepositoryOperationException if this implementation does not support locking.
     * @throws LockException if no lock applies to this node.
     * @throws AccessDeniedException if the curent session does not have pernmission to get the lock.
     * @throws RepositoryException if another error occurs.
     */
    public Lock getLock() throws UnsupportedRepositoryOperationException, LockException, AccessDeniedException, RepositoryException;

    /**
     * Removes the lock on this node. Also removes the properties <code>jcr:lockOwner</code> and
     * <code>jcr:lockIsDeep</code> from this node. These changes are persisted automatically; there is no need to call
     * <code>save</code>.
     * <p/>
     * If this node does not currently hold a lock or
     * holds a lock for which this Session does not have the correct lock token,
     * then a <code>LockException</code> is thrown. Note however that the system
     * may give permission to some users to unlock locks for which they do not have
     * the lock token. Typically such �lock-superuser� capability is intended to
     * facilitate administrational clean-up of orphaned open-scoped locks.
     * <p/>
     * Note that it is possible to unlock a node even if it is checked-in (the lock-related properties will be changed
     * despite the checked-in status).
     * <p/>
     * If the current session does not
     * have sufficient privileges to remove the lock, an <code>AccessDeniedException</code> is thrown.
     * <p/>
     * An <code>InvalidItemStateException</code> is thrown if this node has pending unsaved changes.
     * <p/>
     * An <code>UnsupportedRepositoryOperationException</code> is thrown if this implementation does not support locking.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @throws UnsupportedRepositoryOperationException if this implementation does not support locking.
     * @throws LockException if this node does not currently hold a lock or holds a lock for which this Session does not have the correct lock token
     * @throws AccessDeniedException if the current session does not have permission to unlock this node.
     * @throws InvalidItemStateException if this node has pending unsaved changes.
     * @throws RepositoryException if another error occurs.
     */
    public void unlock() throws UnsupportedRepositoryOperationException, LockException, AccessDeniedException, InvalidItemStateException, RepositoryException;

    /**
     * Returns <code>true</code> if this node holds a lock; otherwise returns <code>false</code>. To <i>hold</i> a
     * lock means that this node has actually had a lock placed on it specifically, as opposed to just having a lock
     * <i>apply</i> to it due to a deep lock held by a node above.
     *
     * @return a <code>boolean</code>.
     * @throws RepositoryException if an error occurs.
     */
    public boolean holdsLock() throws RepositoryException;

    /**
     * Returns <code>true</code> if this node is locked either as a result of a lock held by this node or by a deep
     * lock on a node above this node; otherwise returns <code>false</code>.
     *
     * @return a <code>boolean</code>.
     * @throws RepositoryException if an error occurs.
     */
    public boolean isLocked() throws RepositoryException;
}