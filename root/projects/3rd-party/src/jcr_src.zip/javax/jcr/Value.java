/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import java.io.InputStream;
import java.util.Calendar;

/**
 * A generic holder for the value of a property. A <code>Value</code> object can be used without knowing the actual
 * property type (<code>STRING</code>, <code>DOUBLE</code>, <code>BINARY</code> etc.).
 * <p>
 * Any implementation of this interface must adhere to the following behavior:
 * <ul>
 *   <li>
 *     A <code>Value</code> object can be read using type-specific
 *     <code>get</code> methods. These methods are divided into two groups:
 *     <ul>
 *       <li>
 *         The non-stream <code>get</code> methods <code>getString()</code>, <code>getDate()</code>,
 *         <code>getLong()</code>, <code>getDouble()</code> and <code>getBoolean()</code>.
 *       </li>
 *       <li>
 *          <code>getStream()</code>.
 *       </li>
 *     </ul>
 *    </li>
 *   <li>
 *     Once a <code>Value</code> object has been read once using <code>getStream()</code>, all subsequent calls to
 *     <code>getStream()</code> will return the same <code>Stream</code> object. This may mean, for example, that the
 *     stream returned is fully or partially consumed. In order to get a fresh stream the <code>Value</code> object
 *     must be reacquired via {@link Property#getValue()} or {@link Property#getValues()}.
 *   </li>
 *   <li>
 *     Once a <code>Value</code> object has been read once using <code>getStream()</code>, any subsequent call to any
 *     of the non-stream <code>get</code> methods will throw an <code>IllegalStateException</code>. In order to
 *     successfully invoke a non-stream <code>get</code> method, the <code>Value</code> must be reacquired.
 *   </li>
 *   <li>
 *     Once a <code>Value</code> object has been read once using a non-stream get method, any subsequent call to
 *     <code>getStream()</code> will throw an <code>IllegalStateException</code>. In order to successfully invoke
 *     <code>getStream()</code>, the <code>Value</code> must be reacquired.
 * </ul>
 * <p/>
 * Two <code>Value</code> instances, <code>v1</code> and <code>v2</code>, are considered equal if and only if:
 * <ul>
 * <li><code>v1.getType() == v2.getType()</code>, and,</li>
 * <li><code>v1.getString().equals(v2.getString())</code></li>
 * </ul>
 * Actually comparing two <code>Value</code> instances by converting them to
 * string form may not be practical in some cases (for example, if the values are very large
 * binaries). Consequently, the above is intended as a normative definition of <code>Value</code> equality
 * but not as a procedural test of equality. It is assumed that implementations will have efficient means
 * of determining equality that conform with the above definition.
 *
 */
public interface Value {

    /**
     * Returns a <code>String</code> representation of this value.
     * <p>
     * If this value cannot be converted to a string, a
     * <code>ValueFormatException</code> is thrown.
     * <p>
     * If <code>getStream</code> has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to
     * successfully call <code>getString</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>String</code> representation of the value of this property.
     * @throws ValueFormatException if conversion to a <code>String</code> is not possible.
     * @throws IllegalStateException if <code>getStream</code> has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public String getString() throws ValueFormatException, IllegalStateException, RepositoryException;

    /**
     * Returns an <code>InputStream</code> representation of this value.
     * Uses the standard conversion to binary (see JCR specification)<p>
     * <p>
     * If a non-stream <code>get</code> method has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to successfully call
     * <code>getStream</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return An <code>InputStream</code> representation of this value.
     * @throws IllegalStateException if a non-stream <code>get</code> method has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public InputStream getStream() throws IllegalStateException, RepositoryException;

    /**
     * Returns a <code>long</code> representation of this value.
     * <p>
     * If this value cannot be converted to a <code>long</code>,
     * a <code>ValueFormatException</code> is thrown.
     * <p>
     * If <code>getStream</code> has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to
     * successfully call <code>getLong</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>long</code> representation of this value.
     * @throws ValueFormatException if conversion to an <code>long</code> is not possible.
     * @throws IllegalStateException if <code>getStream</code> has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public long getLong() throws ValueFormatException, IllegalStateException, RepositoryException;

    /**
     * Returns a <code>double</code> representation of this value.
     * <p>
     * If this value cannot be converted to a <code>double</code>, a
     * <code>ValueFormatException</code> is thrown.
     * <p>
     * If <code>getStream</code> has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to
     * successfully call <code>getDouble</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>double</code> representation of this value.
     * @throws ValueFormatException if conversion to a <code>double</code> is not possible.
     * @throws IllegalStateException if <code>getStream</code> has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public double getDouble() throws ValueFormatException, IllegalStateException, RepositoryException;

    /**
     * Returns a <code>Calendar</code> representation of this value.
     * <p>
     * The object returned is a copy of the stored value, so changes to it are not reflected in internal storage.
     * <p>
     * If this value cannot be converted to a <code>Calendar</code>, a
     * <code>ValueFormatException</code> is thrown.
     * <p>
     * If <code>getStream</code> has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to
     * successfully call <code>getDate</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>Calendar</code> representation of this value.
     * @throws ValueFormatException if conversion to a <code>Calendar</code> is not possible.
     * @throws IllegalStateException if <code>getStream</code> has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public Calendar getDate() throws ValueFormatException, IllegalStateException, RepositoryException;

    /**
     * Returns a <code>Boolean</code> representation of this value.
     * <p>
     * If this value cannot be converted to a <code>Boolean</code>, a
     * <code>ValueFormatException</code> is thrown.
     * <p>
     * If <code>getStream</code> has previously been called on this
     * <code>Value</code> instance, an <code>IllegalStateException</code> is thrown.
     * In this case a new <code>Value</code> instance must be acquired in order to
     * successfully call <code>getBoolean</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>Boolean</code> representation of this value.
     * @throws ValueFormatException if conversion to a <code>Boolean</code> is not possible.
     * @throws IllegalStateException if <code>getStream</code> has previously
     * been called on this <code>Value</code> instance.
     * @throws RepositoryException if another error occurs.
     */
    public boolean getBoolean() throws ValueFormatException, IllegalStateException, RepositoryException;

    /**
     * Returns the <code>type</code> of this <code>Value</code>.
     * One of:
     * <ul>
     * <li><code>PropertyType.STRING</code></li>
     * <li><code>PropertyType.DATE</code></li>
     * <li><code>PropertyType.BINARY</code></li>
     * <li><code>PropertyType.DOUBLE</code></li>
     * <li><code>PropertyType.LONG</code></li>
     * <li><code>PropertyType.BOOLEAN</code></li>
     * <li><code>PropertyType.NAME</code></li>
     * <li><code>PropertyType.PATH</code></li>
     * <li><code>PropertyType.REFERENCE</code></li>
     * </ul>
     * See <code>{@link PropertyType}</code>.
     * <p>
     * The type returned is that which was set at property creation.
     */
    public int getType();
}