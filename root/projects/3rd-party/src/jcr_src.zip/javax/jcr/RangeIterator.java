/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import java.util.Iterator;

/**
 * Extends <code>Iterator</code> with the <code>skip</code>, <code>getSize</code>
 * and <code>getPosition</code> methods. The base interface of all type-specific
 * iterators in the <code>javax.jcr</code> and its subpackages.
 */
public interface RangeIterator extends Iterator {

    /**
     * Skip a number of elements in the iterator.
     *
     * @param skipNum the non-negative number of elements to skip
     * @throws java.util.NoSuchElementException
     *          if skipped past the last element in the iterator.
     */
    public void skip(long skipNum);

    /**
     * Returns the number of elements in the iterator.
     * If this information is unavailable, returns -1.
     *
     * @return a long
     */
    public long getSize();

    /**
     * Returns the current position within the iterator. The number
     * returned is the 0-based index of the next element in the iterator,
     * i.e. the one that will be returned on the subsequent <code>next</code> call.
     * <p/>
     * Note that this method does not check if there is a next element,
     * i.e. an empty iterator will always return 0.
     *
     * @return a long
     */
    public long getPosition();
}
