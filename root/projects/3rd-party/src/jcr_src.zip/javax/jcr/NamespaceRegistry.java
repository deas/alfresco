/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

/**
 * <code>NamespaceRegistry</code> represents the global persistent namespace
 * registry of the JCR Repository.
 *
 * @see Workspace#getNamespaceRegistry
 */
public interface NamespaceRegistry {

    /**
     * Sets a one-to-one mapping between prefix and URI in the global namespace registry of this repository.
     * Assigning a new prefix to a URI that already exists in the namespace registry erases the old prefix.
     * In general this can almost always be done, though an implementation is free to prevent particular
     * remappings by throwing a <code>NamespaceException</code>.
     * <p>
     * On the other hand, taking a prefix that is already assigned to a URI and re-assigning it to a new URI
     * in effect unregisters that URI. Therefore, the same restrictions apply to this operation as to
     * <code>NamespaceRegistry.unregisterNamespace</code>:
     * <ul>
     * <li>
     * Attempting to re-assign a built-in prefix (<code>jcr</code>, <code>nt</code>, <code>mix</code>,
     * <code>sv</code>, <code>xml</code>, or the empty prefix) to a new URI will throw a
     * <code>NamespaceException</code>.
     * </li>
     * <li>
     * Attempting to re-assign a prefix that is currently assigned to a URI that is present in content
     * (either within an item name or within the value of a <code>NAME</code> or <code>PATH</code> property)
     * will throw a <code>NamespaceException</code>. This includes prefixes in use within in-content node type
     * definitions.
     * </li>
     * <li>
     * Attempting to register a namespace with a prefix that begins with the characters "<code>xml</code>"
     * (in any combination of case) will throw a <code>NamespaceException</code>.
     * </li>
     * <li>
     * An implementation may prevent the re-assignment of any other namespace prefixes for
     * implementation-specific reasons by throwing a <code>NamespaceException</code>.
     * </li>
     * </ul>
     * In a level 1 implementation, this method always throws an
     * <code>UnsupportedRepositoryOperationException</code>.
     * <p/>
     * If the session associated with the <code>Workspace</code> object through which this registry was acquired does not have sufficient permissions to register the
     * namespace an <code>AccessDeniedException</code> is thrown.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param prefix The prefix to be mapped.
     * @param uri The URI to be mapped.
     * @throws NamespaceException if an illegal attempt is made to register a mapping.
     * @throws UnsupportedRepositoryOperationException in a level 1 implementation
     * @throws AccessDeniedException if the session associated with the <code>Workspace</code> object through which this registry was acquired does not have sufficient permissions to register the namespace.
     * @throws RepositoryException if another error occurs.
     */
    public void	registerNamespace(String prefix, String uri) throws NamespaceException, UnsupportedRepositoryOperationException, AccessDeniedException, RepositoryException;

    /**
     * Removes a namespace mapping from the registry. The following restriction apply:
     * <ul>
     * <li>
     * Attempting to unregister a built-in namespace (<code>jcr</code>, <code>nt</code>,
     * <code>mix</code>, <code>sv</code>, <code>xml</code> or the empty namespace) will
     * throw a <code>NamespaceException</code>.
     * </li>
     * <li>
     * Attempting to unregister a namespace that is currently present in content (either within an
     * item name or within the value of a <code>NAME</code> or <code>PATH</code> property)
     * will throw a <code>NamespaceException</code>. This includes prefixes in use within in-content node type
     * definitions.
     * </li>
     * <li>
     * An attempt to unregister a namespace that is not currently registered will throw a
     * <code>NamespaceException</code>.
     * </li>
     * <li>
     * An implementation may prevent the unregistering of any other namespace for
     * implementation-specific reasons by throwing a <code>NamespaceException</code>.
     * </li>
     * </ul>
     * In a level 1 implementation, this method always throws an
     * <code>UnsupportedRepositoryOperationException</code>.
     * <p/>
     * If the session associated with the <code>Workspace</code> object through which this registry was acquired
     * does not have sufficient permissions to unregister the
     * namespace an <code>AccessDeniedException</code> is thrown.
     * <p/>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @param prefix The prefix of the mapping to be removed.
     * @throws NamespaceException if an illegal attempt is made to remove a mapping.
     * @throws UnsupportedRepositoryOperationException in a level 1 implementation
     * @throws AccessDeniedException if the session associated with the <code>Workspace</code> object through which this registry was acquired does not have sufficient permissions
     * to unregister the namespace.
     * @throws RepositoryException if another error occurs.
     */
    public void unregisterNamespace(String prefix) throws NamespaceException, UnsupportedRepositoryOperationException, AccessDeniedException, RepositoryException;

    /**
     * Returns an array holding all currently registered prefixes.
     * @return a string array
     * @throws RepositoryException if an error occurs.
     */
    public String[] getPrefixes() throws RepositoryException;

    /**
     * Returns an array holding all currently registered URIs.
     * @return a string array
     * @throws RepositoryException if an error occurs.
     */
    public String[] getURIs() throws RepositoryException;

    /**
     * Returns the URI to which the given prefix is mapped.
     * @param prefix a string
     * @return a string
     * @throws NamespaceException if the prefix is unknown.
     * @throws RepositoryException is another error occurs
     */
    public String getURI(String prefix) throws NamespaceException, RepositoryException;

    /**
     * Returns the prefix to which the given URI is mapped
     *
     * @param uri a string
     * @return a string
     * @throws NamespaceException if the URI is unknown.
     * @throws RepositoryException is another error occurs
     */
    public String getPrefix(String uri) throws NamespaceException, RepositoryException;
}
