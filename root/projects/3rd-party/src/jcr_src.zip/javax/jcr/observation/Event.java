/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.observation;

import javax.jcr.RepositoryException;

/**
 * An event fired by the observation mechanism. Also includes
 * constants representing the  event types defined by the JCR standard. Each constant is a
 * power of 2 so that sets of event types can be encoded as a bitmask
 * in a <code>int</code> value.
 *
 * @author Tim Anderson
 */
public interface Event {

    /**
     * An event of this type is generated when a node is added.
     */
     public static final int NODE_ADDED = 1;

    /**
     * An event of this type is generated when a node is removed.
     */
     public static final int NODE_REMOVED = 2;

    /**
     * An event of this type is generated when a property is added.
     */
     public static final int PROPERTY_ADDED = 4;

    /**
     * An event of this type is generated when a property is removed.
     */
     public static final int PROPERTY_REMOVED = 8;

    /**
     * An event of this type is generated when a property is changed.
     */
     public static final int PROPERTY_CHANGED = 16;

    /**
     * Returns the type of this event: a constant defined by this interface.
     * One of:
     * <ul>
     * <li><code>NODE_ADDED</code></li>
     * <li><code>NODE_REMOVED</code></li>
     * <li><code>PROPERTY_ADDED</code></li>
     * <li><code>PROPERTY_REMOVED</code></li>
     * <li><code>PROPERTY_CHANGED</code></li>
     * </ul>
     *
     * @return the type of this event.
     */
    public int getType();

    /**
     * Returns the absolute path of the parent node connected with this event.
     * The interpretation given to the returned path depends upon the type of the event:
     * <ul>
     *   <li>
     *     If the event type is <code>NODE_ADDED</code> then this method returns the absolute path of
     *     the node that was added.
     *   </li>
     *   <li>
     *     If the event type is <code>NODE_REMOVED</code> then this method returns the absolute path of
     *     the node that was removed.
     *   </li>
     *   <li>
     *     If the event type is <code>PROPERTY_ADDED</code> then this method returns the absolute path of
     *     the property that was added.
     *   </li>
     *   <li>
     *     If the event type is <code>PROPERTY_REMOVED</code> then this method returns the absolute path of
     *     the property that was removed.
     *   </li>
     *   <li>
     *     If the event type is <code>PROPERTY_CHANGED</code> then this method returns the absolute path of
     *     of the changed property.
     *   </li>
     * </ul>
     *
     * @throws RepositoryException if an error occurs.
     * @return the absolute path of the parent node connected with this event.
     */
    public String getPath() throws RepositoryException;

    /**
     * Returns the user ID connected with this event. This is the string returned by getUserID of the session that
     * caused the event.
     *
     * @return a <code>String</code>.
     */
    public String getUserID();
}
