/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.observation;

/**
 * An event listener.
 * <p>
 * An <code>EventListener</code> can be registered via the
 * <code>{@link javax.jcr.observation.ObservationManager}</code> object. Event listeners are
 * notified asynchronously, and see events after they occur and the transaction
 * is committed. An event listener only sees events for which the session that
 * registered it has sufficient access rights.
 *
 * @author Tim Anderson
 */
public interface EventListener {

    /**
     * Gets called when an event occurs.
     *
     * @param events The event set recieved.
     */
    public void onEvent(EventIterator events);
}
