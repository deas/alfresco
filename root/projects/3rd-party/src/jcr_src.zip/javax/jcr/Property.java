/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import javax.jcr.nodetype.PropertyDefinition;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;
import javax.jcr.lock.LockException;
import java.io.InputStream;
import java.util.Calendar;

/**
 * A <code>Property</code> object represents the smallest granularity of content
 * storage. A property must have one and only one parent node. A property does
 * not have children. When we say that node A "has" property B it means that B
 * is a child of A.
 * <p>
 * A property consists of a name and a value. See <code>{@link Value}</code>.
 */
public interface Property extends Item {

    /**
     * Sets the value of this property to <code>value</code>.
     * If this property's property type is not constrained by the node type of
     * its parent node, then the property type is changed to that of the supplied
     * <code>value</code>. If the property type is constrained, then a
     * best-effort conversion is attempted. If conversion fails, a
     * <code>ValueFormatException</code> is thrown immediately (not on <code>save</code>).
     * The change will be persisted (if valid) on <code>save</code>
     * <p/>
     * A <code>ConstraintViolationException</code> will be thrown either immediately
     * or on <code>save</code>, if the change would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately
     * or on <code>save</code>, if this property belongs to a node that is versionable and
     * checked-in or is non-versionable but whose nearest versionable ancestor is checked-in.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately
     * or on <code>save</code>, if a lock prevents the setting of the value.
     * Implementations may differ on when this validation is performed.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(Value value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to the <code>values</code> array.
     * If this property's property type is not constrained by the node type of
     * its parent node, then the property type is changed to that of the supplied
     * <code>values</code>. If the property type is constrained, then a
     * best-effort conversion is attempted. If conversion fails, a
     * <code>ValueFormatException</code> is thrown immediately (not on <code>save</code>).
     * If this property is not a multi-valued then a <code>ValueFormatException</code> is
     * thrown immediately. The change will be persisted (if valid) on <code>save</code>.
     * <p/>
     * A <code>ConstraintViolationException</code> will be thrown either immediately
     * or on <code>save</code>, if the change would violate a node type or implementation-specific constraint.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>VersionException</code> will be thrown either immediately
     * or on <code>save</code>, if this property belongs to a node that is versionable and
     * checked-in or is non-versionable but whose nearest versionable ancestor is checked-in.
     * Implementations may differ on when this validation is performed.
     * <p/>
     * A <code>LockException</code> will be thrown either immediately
     * or on <code>save</code>, if a lock prevents the setting of the value.
     * Implementations may differ on when this validation is performed.
     *
     * @param values The new values to set the property to.
     * @throws ValueFormatException if the type or format of the specified values
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(Value[] values) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>String</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(String value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to the <code>values</code> array.
     * Same as <code>{@link #setValue(Value[] values)}</code> except that the
     * values are specified as a <code>String[]</code>.
     *
     * @param values The new values to set the property to.
     * @throws ValueFormatException if the type or format of the specified values
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(String[] values) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>InputStream</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(InputStream value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>long</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(long value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>double</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(double value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>Calendar</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(Calendar value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets the value of this property to <code>value</code>.
     * Same as <code>{@link #setValue(Value value)}</code> except that the
     * value is specified as a <code>boolean</code>.
     *
     * @param value The new value to set the property to.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(boolean value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Sets this REFERENCE property to refer to the specified node. If
     * this property is not of type REFERENCE or the specified node is
     * not referenceable (i.e., is not of mixin node type
     * <code>mix:referenceable</code> and therefore does not have a UUID) then a
     * <code>ValueFormatException</code> is thrown.
     *
     * @param value The node to which this REFERENCE property will refer.
     * @throws ValueFormatException if the type or format of the specified value
     * is incompatible with the type of this property.
     * @throws VersionException if this property belongs to a node that is versionable and checked-in
     * or is non-versionable but whose nearest versionable ancestor is checked-in and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws LockException if a lock prevents the setting of the value and this
     * implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws ConstraintViolationException if the change would violate a node-type or other constraint
     * and this implementation performs this validation immediately instead of waiting until <code>save</code>.
     * @throws RepositoryException if another error occurs.
     */
    public void setValue(Node value) throws ValueFormatException, VersionException, LockException, ConstraintViolationException, RepositoryException;

    /**
     * Returns the value of this  property as a generic
     * <code>Value</code> object.
     * <p>
     * If the property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p/>
     * The object returned is a copy of the stored value and is immutable.
     *
     * @throws ValueFormatException if the property is multi-valued.
     * @throws RepositoryException if another error occurs.
     *
     * @return the value
     */
    public Value getValue() throws ValueFormatException, RepositoryException;

    /**
     * Returns an array of all the values of this property. Used to access
     * multi-value properties. If the property is single-valued, this method throws a
     * <code>ValueFormatException</code>. The array returned is a copy of the stored
     * values, so changes to it are not reflected in internal storage.
     *
     * @throws ValueFormatException if the property is single-valued.
     * @throws RepositoryException if another error occurs.
     *
     * @return a <code>Value</code> array
     */
    public Value[] getValues() throws ValueFormatException, RepositoryException;

    /**
     * Returns a <code>String</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getString()</code>. See {@link Value}.
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If the value of this property cannot be converted to a
     * string, a <code>ValueFormatException</code> is thrown.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A string representation of the value of this property.
     * @throws ValueFormatException if conversion to a string is not possible or if the
     * property is multi-valued.
     * @throws RepositoryException if another error occurs.
     */
    public String getString() throws ValueFormatException, RepositoryException;

    /**
     * Returns an <code>InputStream</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getStream()</code>. See {@link Value}.
     * <p>
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A stream representation of the value of this property.
     * @throws ValueFormatException if the property is multi-valued.
     * @throws RepositoryException if another error occurs
     */
    public InputStream getStream() throws ValueFormatException, RepositoryException;

    /**
     * Returns a <code>long</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getLong()</code>. See {@link Value}.
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If the value of this property cannot be converted to a
     * <code>long</code>, a <code>ValueFormatException</code> is thrown.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A <code>long</code> representation of the value of this property.
     * @throws ValueFormatException if conversion to a string is not possible or if the
     * property is multi-valued.
     * @throws RepositoryException if another error occurs
     */
    public long getLong() throws ValueFormatException, RepositoryException;

    /**
     * Returns a <code>double</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getDouble()</code>. See {@link Value}.
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If the value of this property cannot be converted to a
     * double, a <code>ValueFormatException</code> is thrown.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A double representation of the value of this property.
     * @throws ValueFormatException if conversion to a string is not possible or if the
     * property is multi-valued.
     * @throws RepositoryException if another error occurs
     */
    public double getDouble() throws ValueFormatException, RepositoryException;

    /**
     * Returns a <code>Calendar</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getDate()</code>. See {@link Value}.
     * <p/>
     * The object returned is a copy of the stored value, so changes to it are not reflected in internal storage.
     * <p/>
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If the value of this property cannot be converted to a
     * date, a <code>ValueFormatException</code> is thrown.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A date (<code>Calendar</code> object)  representation of the value of this property.
     * @throws ValueFormatException if conversion to a string is not possible or if the
     * property is multi-valued.
     * @throws RepositoryException if another error occurs
     */
    public Calendar getDate() throws ValueFormatException, RepositoryException;

    /**
     * Returns a <code>boolean</code> representation of the value of this
     * property. A shortcut for
     * <code>Property.getValue().getBoolean()</code>. See {@link Value}.
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If the value of this property cannot be converted to a
     * boolean, a <code>ValueFormatException</code> is thrown.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return A boolean representation of the value of this property.
     * @throws ValueFormatException if conversion to a string is not possible or if the
     * property is multi-valued.
     * @throws RepositoryException if another error occurs
     */
    public boolean getBoolean() throws ValueFormatException, RepositoryException;

    /**
     * If this property is of type <code>REFERENCE</code>
     * this method returns the node to which this property refers.
     * <p>
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     * <p>
     * If this property cannot be coverted to a reference, then a <code>ValueFormatException</code> is thrown.
     * <p>
     * If this property is a REFERENCE property but is currently part of the frozen state of a version in version
     * storage, this method will throw a <code>ValueFormatException</code>.
     * <p>
     * A <code>RepositoryException</code> is thrown if another error occurs.
     *
     * @return the referenced Node
     * @throws ValueFormatException if this property cannot be converted to a reference, if the
     * property is multi-valued or if this property is a REFERENCE property but is currently part of the frozen
     * state of a version in version storage.
     * @throws RepositoryException if another error occurs
     */
    public Node getNode() throws ValueFormatException, RepositoryException;

    /**
     * Returns the length of the value of this property.
     * <p>
     * Returns the length in bytes if the value is a
     * <code>PropertyType.BINARY</code>, otherwise it returns the number of
     * characters needed to display the value in its string form.
     * <p/>
     * Returns �1 if the implementation cannot determine the length.
     * <p/>
     * If this property is multi-valued, this method throws a <code>ValueFormatException</code>.
     *
     * @return an <code>long</code>.
     * @throws ValueFormatException if this property is multi-valued.
     * @throws RepositoryException if another error occurs.
     */
    public long getLength() throws ValueFormatException, RepositoryException;

    /**
     * Returns an array holding the lengths of the values of this (multi-value) property in bytes
     * if the values are <code>PropertyType.BINARY</code>, otherwise it returns the number of
     * characters needed to display the value in its string form. The order of the
     * length values corresponds to the order of the values in the property.
     * <p/>
     * Returns a <code>�1</code> in the appropriate position if the implementation cannot determine
     * the length of a value.
     * <p/>
     * If this property is single-valued, this method throws a <code>ValueFormatException</code>.
     * <p/>
     * A RepositoryException is thrown if another error occurs.
     * @return an array of lengths
     * @throws ValueFormatException if this property is single-valued.
     * @throws RepositoryException if another error occurs.
     */
    public long[] getLengths() throws ValueFormatException, RepositoryException;

    /**
     * Returns the property definition that applies to this property. In some cases there may appear to
     * be more than one definition that could apply to this node. However, it is assumed that upon
     * creation of this property, a single particular definition was used and it is <i>that</i>
     * definition that this method returns. How this governing definition is selected upon property
     * creation from among others which may have been applicable is an implementation issue and is not
     * covered by this specification.
     *
     * @see javax.jcr.nodetype.NodeType#getPropertyDefinitions
     * @throws RepositoryException if an error occurs.
     * @return a <code>PropertyDefinition</code> object.
     */
    public PropertyDefinition getDefinition() throws RepositoryException;

    /**
     * Returns the type of this <code>Property</code>. One of:
     * <ul>
     * <li><code>PropertyType.STRING</code></li>
     * <li><code>PropertyType.BINARY</code></li>
     * <li><code>PropertyType.DATE</code></li>
     * <li><code>PropertyType.DOUBLE</code></li>
     * <li><code>PropertyType.LONG</code></li>
     * <li><code>PropertyType.BOOLEAN</code></li>
     * <li><code>PropertyType.NAME</code></li>
     * <li><code>PropertyType.PATH</code></li>
     * <li><code>PropertyType.REFERENCE</code></li>
     * </ul>
     * The type returned is that which was set at property creation. Note that for some property <code>p</code>,
     * the type returned by <code>p.getType()</code> may differ from the type returned by
     * <code>p.getDefinition.getRequiredType()</code> only in the case where the latter returns <code>UNDEFINED</code>.
     * The type of a property instance is never <code>UNDEFINED</code> (it must always have some actual type).
     *
     * @return an int
     * @throws RepositoryException if an error occurs
     */
    public int getType() throws RepositoryException;
}