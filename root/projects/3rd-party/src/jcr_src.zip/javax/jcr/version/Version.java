/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.version;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import java.util.Calendar;

/**
 * A <code>Version</code> object wraps an <code>nt:version</code> node. It
 * provides convenient access to version information.
 */
public interface Version extends Node {

    /**
     * Returns the <code>VersionHistory</code> that contains this <code>Version</code>.
     * @return the <code>VersionHistory</code> that contains this <code>Version</code>.
     * @throws RepositoryException if an error occurs.
     */
     public VersionHistory getContainingHistory() throws RepositoryException;

    /**
     * Returns the date this version was created. This corresponds to the value
     * of the <code>jcr:created</code> property in the <code>nt:version</code>
     * node that represents this version.
     *
     * @return a <code>Calendar</code> object
     * @throws RepositoryException if an error occurs.
     */
    public Calendar getCreated() throws RepositoryException;

    /**
     * Returns the successor versions of this version. This corresponds to
     * returning all the <code>nt:version</code> nodes referenced by the
     * <code>jcr:successors</code> multi-value property in the
     * <code>nt:version</code> node that represents this version.
     *
     * @return a <code>Version</code> array.
     * @throws RepositoryException if an error occurs.
     */
    public Version[] getSuccessors() throws RepositoryException;

    /**
     * Returns the predecessor versions of this version. This corresponds to
     * returning all the <code>nt:version</code> nodes whose
     * <code>jcr:successors</code> property includes a reference to the
     * <code>nt:version</code> node that represents this version.
     *
     * @return a <code>Version</code> array.
     * @throws RepositoryException if an error occurs.
     */
    public Version[] getPredecessors() throws RepositoryException;
}