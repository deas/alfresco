/*
 * Copyright 2005 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * Main exception thrown by classes in this package. May contain an error
 * message and/or another nested exception.
 */
public class RepositoryException extends Exception {

    /**
     * Root failure cause
     */
    protected Throwable rootCause;

    /**
     * Constructs a new instance of this class with <code>null</code> as its
     * detail message.
     */
    public RepositoryException() {
	super();
    }

    /**
     * Constructs a new instance of this class with the specified detail
     * message.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the {@link #getMessage()} method.
     */
    public RepositoryException(String message) {
	super(message);
    }

    /**
     * Constructs a new instance of this class with the specified detail
     * message and root cause.
     *
     * @param message   the detail message. The detail message is saved for
     *                  later retrieval by the {@link #getMessage()} method.
     * @param rootCause root failure cause
     */
    public RepositoryException(String message, Throwable rootCause) {
	super(message);
	this.rootCause = rootCause;
    }

    /**
     * Constructs a new instance of this class with the specified root cause.
     *
     * @param rootCause root failure cause
     */
    public RepositoryException(Throwable rootCause) {
	super();
	this.rootCause = rootCause;
    }

    /**
     * Returns the detail message, including the message from the nested
     * exception if there is one.
     *
     * @return the detail message (which may be <code>null</code>).
     */
    public String getMessage() {
	String s = super.getMessage();
	if (rootCause == null) {
	    return s;
	} else {
	    String s2 = rootCause.getMessage();
	    return s == null ? s2 : s + ": " + s2;
	}
    }

    /**
     * Returns the localized message, including the localized message from the
     * nested exception if there is one.
     *
     * @return The localized description of this exception.
     */
    public String getLocalizedMessage() {
	String s = super.getLocalizedMessage();
	if (rootCause == null) {
	    return s;
	} else {
	    String s2 = rootCause.getLocalizedMessage();
	    return s == null ? s2 : s + ": " + s2;
	}
    }

    /**
     * Returns the cause of this exception or <code>null</code> if the
     * cause is nonexistent or unknown. (The cause is the throwable that
     * caused this exception to get thrown.)
     *
     * @return the cause of this exception or <code>null</code> if the
     *         cause is nonexistent or unknown.
     */
    public Throwable getCause() {
	return rootCause;
    }

    /**
     * Prints this <code>RepositoryException</code> and its backtrace to the
     * standard error stream.
     */
    public void printStackTrace() {
	printStackTrace(System.err);
    }

    /**
     * Prints this <code>RepositoryException</code> and its backtrace to the
     * specified print stream.
     *
     * @param s <code>PrintStream</code> to use for output
     */
    public void printStackTrace(PrintStream s) {
	synchronized (s) {
	    super.printStackTrace(s);
	    if (rootCause != null) {
		rootCause.printStackTrace(s);
	    }
	}
    }

    /**
     * Prints this <code>RepositoryException</code> and its backtrace to
     * the specified print writer.
     *
     * @param s <code>PrintWriter</code> to use for output
     */
    public void printStackTrace(PrintWriter s) {
	synchronized (s) {
	    super.printStackTrace(s);
	    if (rootCause != null) {
		rootCause.printStackTrace(s);
	    }
	}
    }
}
