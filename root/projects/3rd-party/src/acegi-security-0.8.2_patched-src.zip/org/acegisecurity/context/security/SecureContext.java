/* Copyright 2004, 2005 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sf.acegisecurity.context.security;

import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.context.Context;


/**
 * A {@link Context} that also stores {@link Authentication} information.
 * 
 * <p>
 * This interface must be implemented on contexts that will be presented to the
 * Acegi Security System for Spring, as it is required by the  {@link
 * net.sf.acegisecurity.intercept.AbstractSecurityInterceptor}.
 * </p>
 *
 * @author Ben Alex
 * @version $Id: SecureContext.java 644 2005-02-21 06:48:31Z benalex $
 */
public interface SecureContext extends Context {
    //~ Methods ================================================================

    public void setAuthentication(Authentication newAuthentication);

    public Authentication getAuthentication();
}
