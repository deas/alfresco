obj.css({"float": "left"});
obj.css({cssFloat:"left"});