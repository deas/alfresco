package org.alfresco.share;

import java.util.Calendar;

import org.alfresco.share.util.AbstractTests;
import org.alfresco.share.util.ShareUser;
import org.alfresco.share.util.api.CreateUserAPI;
import org.alfresco.webdrone.WebDrone;
import org.alfresco.webdrone.annotations.DataGroup;
import org.alfresco.webdrone.annotations.DataSetup;
import org.alfresco.webdrone.share.DashBoardPage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MyDashBoardTest extends AbstractTests
{
    private static Log logger = LogFactory.getLog(LoginTest.class);    
    
    protected String testUser;
    protected String testUserPass = DEFAULT_PASSWORD;
    
    protected String siteName = "";

	/**
     * Class includes: Tests from TestLink in Area: My DashBoard Tests
     * <ul>
     *   <li>Test User DashBoard UI</li>
     *   <li>Test various Entries in default Dashlets</li>
     * </ul>
     */
    @BeforeClass
    public void setup() throws Exception
    {
        super.setup();
        testName = this.getClass().getSimpleName();
        testUser = testUser + "@" + DOMAIN_FREE;
        logger.info("[Suite ] : Start Tests in: " + testName);
    }
    @AfterClass
    public void cleanup()
    {
        super.tearDown();
        logger.info("[Suite ] : End of Tests in: " + testName);
    }
    
    @DataSetup(testLinkId="cloud-1506", groups=DataGroup.MY_DASH_BOARD)
    public void dataPrep_MyDashBoard_1506(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);
    }

	/**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Check Logo the Dashboard</li>
     * </ul>
     */
    @Test
    public void cloud_1506()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = this.getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, testUserPass);
    		
    		//Open DashBoard
            DashBoardPage myDashPage = ShareUser.openUserDashboard(drone);
            
            //Check Logo
            Assert.assertTrue(myDashPage.isLogoPresent(), testName + " : Fail : Logo Not Found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    } 
    
    @DataSetup(testLinkId="cloud-1507", groups=DataGroup.MY_DASH_BOARD)
    public void dataPrep_MyDashBoard_1507(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);
        
        // Login
        ShareUser.login(drone, testUser, testUserPass);
    }
    
    /**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Check CopyRight Info on the Dashboard</li>
     * </ul>
     */
    @Test
    public void cloud_1507()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = this.getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);
    	    
    	    Calendar now = Calendar.getInstance();
    	    int toYear = now.get(Calendar.YEAR);
    	    if (!drone.getAlfrescoVersion().isCloud())
    	    {
    	        toYear = 2012;
    	    }
    	    String entry = "Alfresco Software, Inc. © 2005-" + toYear + " All rights reserved.";    	

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, testUserPass);

    	    //Open DashBoard
            DashBoardPage myDashPage = ShareUser.openUserDashboard(drone);
            
            //Check CopyRight Info
            Assert.assertEquals(myDashPage.getCopyRight(), entry, testName + " : Fail : Copyright Info does not match");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
    
    // MyDashBoard Tests
    @DataSetup(testLinkId="cloud-236", groups=DataGroup.MY_DASH_BOARD)
    public static void dataPrep_MyDashBoard_236(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);
    }
    
    /**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Check CopyRight Info on the Dashboard</li>
     * </ul>
     */
    @Test
    public void cloud_236()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = this.getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, testUserPass);

    	    //Open DashBoard
            DashBoardPage myDashPage = ShareUser.openUserDashboard(drone);
            
            //Check Default Components: Welcome Widget: Cloud Only
            if (drone.getAlfrescoVersion().isCloud())
            {
            	Assert.assertTrue(myDashPage.panelExists(uiWelcomePanel), testName + " : Fail : Welcome Widget not found");
            }	
            
            //Check Default Components: My Sites
            Assert.assertTrue(myDashPage.panelExists(uiMySitesDashlet), testName + " : Fail : My Sites Dashlet not found");
            
            //Check Default Components: My Documents
            Assert.assertTrue(myDashPage.panelExists(uiMyDocuments), testName + " : Fail : My Documents Dashlet not found");
            
            //Check Default Components: My Tasks
            Assert.assertTrue(myDashPage.panelExists(uiMyTasks), testName + " : Fail : My Tasks Dashlet not found");
            
            //Check Default Components: My Activities
            Assert.assertTrue(myDashPage.panelExists(uiMyActivities), testName + " : Fail : My Activities Dashlet not found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
    
    @DataSetup(testLinkId="cloud-332", groups=DataGroup.MY_DASH_BOARD)
    public static void dataPrep_MyDashBoard_332(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);
    }

    /**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Create Site: Public</li>
     *   <li>Open User Dash-board</li>
     *   <li>Check that the User Dash-board > My Sites Dashlet shows the new Site</li>
     * </ul>
     */
    @Test
    public void cloud_332()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = this.getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);
    	    String siteName = getSiteName(testName) + System.currentTimeMillis();

    	    String entry = "";

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, testUserPass);

    	    //createSite
            ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC);

    		//Search for Site
            ShareUser.openUserDashboard(drone);

            //Check Activity Feed: Site Name
            entry = siteName;
            Assert.assertTrue(ShareUser.searchMyDashBoardWithRetry(drone, DASHLET_SITES, entry, true),"Activity Entry not found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
}
