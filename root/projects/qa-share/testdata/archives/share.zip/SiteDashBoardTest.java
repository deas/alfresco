package org.alfresco.share;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.alfresco.share.util.AbstractTests;
import org.alfresco.share.util.ShareUser;
import org.alfresco.share.util.ShareUserSitePage;
import org.alfresco.share.util.api.CreateUserAPI;
import org.alfresco.webdrone.AlfrescoVersion;
import org.alfresco.webdrone.WebDrone;
import org.alfresco.webdrone.WebDroneImpl;
import org.alfresco.webdrone.annotations.DataGroup;
import org.alfresco.webdrone.annotations.DataSetup;
import org.alfresco.webdrone.share.dashlet.SiteContentDashlet;
import org.alfresco.webdrone.share.site.SiteDashboardPage;
import org.alfresco.webdrone.share.site.document.DocumentDetailsPage;
import org.alfresco.webdrone.share.site.document.DocumentLibraryPage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SiteDashBoardTest extends AbstractTests
{
    private static Log logger = LogFactory.getLog(SiteDashBoardTest.class);    
    
    protected String testUser;
    
    protected String siteName = "";

	/**
     * Class includes: Tests from TestLink in Area: Site DashBoard Tests
     * <ul>
     *   <li>Perform an Activity on Site</li>
     *   <li>Site DashBoard shows Activity Feed</li>
     * </ul>
     */
    @BeforeClass
    public void setup() throws Exception
    {
        super.setup();
        testName = this.getClass().getSimpleName();
        testUser = testName + "@" + DOMAIN_FREE; 
        logger.info("[Suite ] : Start Tests in: " + testName);
    }
    
    @AfterClass
    public void cleanup()
    {
        super.tearDown();
        logger.info("[Suite ] : End of Tests in: " + testName);
    }
 
 // SiteDashBoard Tests
    @DataSetup(testLinkId="cloud-575", groups=DataGroup.SITE_DASH_BOARD)
    public static void dataPrep_SiteDashBoard_575(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);
        String siteName = getSiteName(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);
        
        // Login
        ShareUser.login(drone, testUser, DEFAULT_PASSWORD);
        
        // Site
        ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC);
        
    }
    
	/**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Create Site: Private</li>
     *   <li>Upload File</li>
     *   <li>Open User Dash-board</li>
     *   <li>Check that the User Dash-board > My Documents Dashlet shows the new file</li>
     * </ul>
     */
    @Test
    public void cloud_575()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);
    	    String siteName = getSiteName(testName);
    	    String fileName = getFileName(testName) + "-" + System.currentTimeMillis() + "." + "txt";

    	    String[] fileInfo = {fileName, DOCLIB};

    	    String activityEntry = "";

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, DEFAULT_PASSWORD);
    	    
    	    //Open Site DashBoard
    	    ShareUser.openSiteDashboard(drone, siteName);
            
            //uploadFile
            ShareUser.uploadFileInFolder(drone, fileInfo);            
                        
            //openUserDashboard(drone);
            ShareUser.openUserDashboard(drone);

            //addDashlet(drone, myDocuments);

            //Check Activity Feed: Add Document
            activityEntry = testUser + FEED_CONTENT_ADDED + FEED_FOR_FILE + fileName + FEED_LOCATION + siteName;
            
            Boolean entryFound = ShareUser.searchMyDashBoardWithRetry(drone, DASHLET_ACTIVITIES, activityEntry, true);
        
            Assert.assertTrue(entryFound,"Activity Entry not found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName, e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
    
    @DataSetup(testLinkId="cloud-578", groups=DataGroup.SITE_DASH_BOARD)
    public void dataPrep_SiteDashBoard_578(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);
        String siteName = getSiteName(testName);

        // User
        String[] testUserInfo = new String[] {testUser};        

        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);

        // Login
        ShareUser.login(drone, testUser, DEFAULT_PASSWORD);

        // Site
        ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC);
    }

    /**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Create Site</li>
     *   <li>Upload Document</li>
     *   <li>Like Document, Check Like Count = 1</li>
     *   <li>Open User Dash-board</li>
     *   <li>Check that the User Dash-board > My Documents Dashlet shows the new file</li>
     * </ul>
     */
    @Test
    public void cloud_578()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);
    	    String siteName = getSiteName(testName);
    	    String fileName = getFileName(testName) + "-" + System.currentTimeMillis() + "." + "txt";

    	    String[] fileInfo = {fileName};

    	    String activityEntry = "";

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, DEFAULT_PASSWORD);

    	    //createSite
    	    //ShareUser.createSite(drone, siteName, ShareUser.constSiteVisibilityPublic);

    	    //Open Site DashBoard
    	    ShareUser.openSiteDashboard(drone, siteName);

    	    //uploadFile
    	    ShareUser.uploadFileInFolder(drone, fileInfo);           

    	    //Open Document Details
    	    DocumentLibraryPage docPage = drone.getCurrentPage().render(refreshDuration);

    	    //Like Document
    	    DocumentDetailsPage docDetailsPage = docPage.selectFile(fileName).render();

    	    //Check Like count is zero
    	    Assert.assertEquals(docDetailsPage.getLikeCount(),"0","Test: 711: Fail: Incorrect Like Count. Expected 0 when no likes");            
    	    docDetailsPage.selectLike().render(maxWaitTime);

    	    //Check Like Count
    	    Assert.assertEquals(docDetailsPage.getLikeCount(),"1","Test: 711: Fail: Incorrect Like Count. Expected 1, on Like Document");

    	    //Unlike Document
    	    docDetailsPage.selectLike().render(maxWaitTime);
    	    Assert.assertEquals(docDetailsPage.getLikeCount(),"0","Test: 711: Fail: Incorrect Like Count. Expected 0, on Unlike Document");            

    	    //openUserDashboard(drone);
    	    ShareUser.openUserDashboard(drone);

    	    ////addDashlet(drone, myDocuments);

    	    //Check Activity Feed: Liked Document
    	    activityEntry = testUser + FEED_CONTENT_LIKED + FEED_FOR_FILE + fileName + FEED_LOCATION + siteName;

            Boolean entryFound = ShareUser.searchMyDashBoardWithRetry(drone, DASHLET_ACTIVITIES, activityEntry, true);
            
            Assert.assertTrue(entryFound,"Activity Entry not found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
    
    @DataSetup(testLinkId="cloud-580", groups=DataGroup.SITE_DASH_BOARD)
    public void dataPrep_SiteDashBoard_580(WebDrone drone) throws Exception
    {
        String testName = getTestName();
        String testUser = getUserNameFreeDomain(testName);
        String[] testUserInfo = new String[] {testUser};        
                
        String siteName = getSiteName(testName);

        // User
        CreateUserAPI.CreateActivateUser(drone, ADMIN_USERNAME, testUserInfo);

        // Login
        ShareUser.login(drone, testUser, DEFAULT_PASSWORD);

        // Site
        ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC);
    }
    
	/**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Create Site</li>
     *   <li>Create Folder</li>
     *   <li>Open User Dash-board</li>
     *   <li>Check that the User Dash-board > My Documents Dashlet shows the activity feed</li>
     * </ul>
     */
    @Test
    public void cloud_580()
    {
    	try
    	{
    	    /**Start Test*/
    	    testName = getTestName();

    	    /**Test Data Setup*/
    	    String testUser = getUserNameFreeDomain(testName);
    	    String siteName = getSiteName(testName);
    	    //String siteName = testName + "-" + System.currentTimeMillis();
    	    String folderName = getFolderName(testName) + "-" + System.currentTimeMillis();

    	    String activityEntry = "";

    	    /**Test Steps*/
    	    //Login
    	    ShareUser.login(drone, testUser, DEFAULT_PASSWORD);

    	    //createSite
            //ShareUser.createSite(drone, siteName, ShareUser.constSiteVisibilityPublic);
    	    
    	    //Open Site DashBoard
    	    ShareUser.openSiteDashboard(drone, siteName);

            //uploadFile
    	    ShareUserSitePage.createFolder(drone, folderName, folderName+"-Description");
            
            //openUserDashboard(drone);
            ShareUser.openUserDashboard(drone);

            //addDashlet(drone, myDocuments);

            //Check Activity Feed: Add Folder
            activityEntry = testUser + FEED_CONTENT_ADDED + FEED_FOR_FOLDER + folderName + FEED_LOCATION + siteName;

            Boolean entryFound = ShareUser.searchMyDashBoardWithRetry(drone, DASHLET_ACTIVITIES, activityEntry, true);
            
            Assert.assertTrue(entryFound,"Activity Entry not found");
    	}
    	catch (Throwable e)
        {
    		reportError(drone,testName,e);
    	}
    	finally
    	{
    		testCleanup(drone, testName);
    	}
    }   
 
    @DataSetup(testLinkId = "7932", groups = { DataGroup.MY_DASH_BOARD })
    public static void dataPrep_testSiteContentDashletFilters_7932(WebDrone drone) throws Exception
    {
        String testName = getTestName();
       
        String siteName = getSiteName(testName);

        // Login
        ShareUser.login(drone,  username, password);

        // Site
        ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC);
    }
    
    /**
     * Test:
     * <ul>
     *   <li>Login</li>
     *   <li>Create Site: Private</li>
     *   <li>Check that the created site contents dashlet > Search filters </li>
     * </ul>
     */
    @Test
    public void testSiteContentDashletFilters_7932()
    {
       try
        {
            /** Start Test */
            testName = this.getTestName();

            /** Test Data Setup */
           // String testUser = "testUsers"; //getUserNameFreeDomain(testName);
            String siteName = getSiteName(testName);

            List<String> expectedValues = new ArrayList<String>();

            expectedValues.add("I've Recently Modified");
            expectedValues.add("I'm Editing");
            expectedValues.add("My Favorites");
            
            if(AlfrescoVersion.Cloud.equals(drone.getAlfrescoVersion())) {
                expectedValues.add("Synced content");
                expectedValues.add("Synced with Error");
            }

            String actualHelpBalloonMessage = "This dashlet makes it easy to keep track of your recent changes to library content in this site. Clicking the item name or thumbnail takes you to the details page so you can preview or work with the item.There are two views for this dashlet. The detailed view lets you:Mark an item as a favorite so it appears in Favorites lists for easy accessLike (and unlike) an itemJump to the item details page to leave a comment";

            /** Test Steps */

            // Login
            ShareUser.login(drone, username, password);

            // Open Site DashBoard
            SiteDashboardPage siteDashBoardPage =(SiteDashboardPage) ShareUser.openSiteDashboard(drone, siteName);
           
            SiteContentDashlet siteContentDashlet = siteDashBoardPage.getDashlet(SITE_CONTENT_DASHLET).render();
            
            Assert.assertTrue(siteContentDashlet.isSimpleButtonDisplayed());
            Assert.assertTrue(siteContentDashlet.isDetailButtonDisplayed());
            
            ShareUser.clickOnFilterButtton(siteContentDashlet);

            List<WebElement> list = ShareUser.getSiteContentDashletFilters(siteContentDashlet);

            for (WebElement link : list)
            {
                Assert.assertTrue(expectedValues.contains(link.getText()));
            }
            
            ShareUser.clickOnHelpButton(siteContentDashlet);
            
            String msg = ShareUser.getHelpBalloon(siteContentDashlet);
           
            Assert.assertNotNull(msg);
            Assert.assertEquals(actualHelpBalloonMessage, msg);

            ShareUser.closeHelpBalloon(siteContentDashlet);
        }
        catch (Throwable e)
        {
            reportError(drone, testName, e);
        }
        finally
        {
            testCleanup(drone, testName);
        }
    }
}