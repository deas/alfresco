/**
 * 
 */
package org.alfresco.share;

import java.io.File;
import java.util.List;

import org.alfresco.share.util.AbstractTests;
import org.alfresco.share.util.ShareUser;
import org.alfresco.share.util.ShareUserSitePage;
import org.alfresco.webdrone.AlfrescoVersion;
import org.alfresco.webdrone.WebDrone;
import org.alfresco.webdrone.annotations.DataGroup;
import org.alfresco.webdrone.annotations.DataSetup;
import org.alfresco.webdrone.share.site.document.DocumentDetailsPage;
import org.alfresco.webdrone.share.site.document.DocumentLibraryPage;
import org.alfresco.webdrone.share.site.document.FileDirectoryInfo;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * This class
 * @author cbairaajoni
 *
 */
public class SiteDocumentLibraryTest extends AbstractTests {
    private static Log logger = LogFactory.getLog(SiteDocumentLibraryTest.class);

    //File name needs to be changed according to the file used to test upload. 
    //And this file is presents in the testdata folder inside project.
    private static String UNSUPPORTED_FORMAT = "Test_3893_Unsupported_Format.mm";

   
    protected String testUser;
    protected String siteName = "";

    /**
     * Class includes: Tests from TestLink in Area: Site Document Library Tests
     * <ul>
     * <li>Perform an Activity on Library</li>
     * <li>Site Document library shows documents</li>
     * </ul>
     */
    @BeforeClass
    public void setup() throws Exception {
        super.setup();
        testName = this.getClass().getSimpleName();
        testUser = testName + "@" + DOMAIN_FREE;
        logger.info("[Suite ] : Start Tests in: " + testName);
    }

    @AfterClass
    public void cleanup() {
        super.tearDown();
        logger.info("[Suite ] : End of Tests in: " + testName);
    }     
        
    @DataSetup(testLinkId = "3893", groups = { DataGroup.SITE_DASH_BOARD })
    public static void dataPrep_testUnsupportedDocuments_3893(WebDrone drone) throws Exception {
        String fileLocation;
        File file;

        String testName = getTestName();

        String siteName = getSiteName(testName);

        // Enterprise Login
        ShareUser.login(drone, username, password);

        // Site
        ShareUser.createSite(drone, siteName, ShareUser.SITE_VISIBILITY_PUBLIC).render(maxWaitTime);

        ShareUser.openSitesDocumentLibrary(drone, siteName).render(maxWaitTime);

        // uploading unsupported format (*.djvu, *.mm)
        fileLocation = DATA_FOLDER + UNSUPPORTED_FORMAT;
        file = new File(fileLocation);
        ShareUserSitePage.uploadFile(drone, file);
    }

    /**
     * This test is valid for Cloud and Enterprise4.1 only. Enterprise4.2 UI development changes are in progress.
     * Test:
     * <ul>
     * <li>Login</li>
     * <li>Create Site</li>
     * <li>Open Document library page</li>
     * <li>select added any unsupported document</li>
     * <li>Document details page opens</li>
     * <li>
     * <li>verify document preview should not be displayed</li>
     * <li>verify download link should displayed</li>
     * <li>click on download link</li>
     * </ul>
     */
    @Test()
    public void testUnsupportedDocumentsShouldNotBePreviewed_3893() {
        logger.info("SiteDashBoardTest: testUnsupportedDocumentsShouldNotBePreviewed_3893");

        DocumentDetailsPage docDetailsPage = null;
        try {
            /** Start Test */
            testName = getTestName();

            /** Test Data Setup */
            String siteName = getSiteName(testName);

            // Login
            ShareUser.login(drone, username, password);

            ShareUser.openSiteDashboard(drone, siteName);

            docDetailsPage = verifyPreviewAndUnsupportedMessage(UNSUPPORTED_FORMAT, docDetailsPage);
            
            Assert.assertNotNull(docDetailsPage);

            clickOnDownloadLink(docDetailsPage);
            
        } catch (Throwable e) {
            reportError(drone, testName, e);
        } finally {
            testCleanup(drone, testName);
        }
    }

   /**
     * @param docDetailsPage
     * @param libraryPage
     * @param files
     * @return DocumentDetailsPage
     */
    private DocumentDetailsPage verifyPreviewAndUnsupportedMessage(String fileName, DocumentDetailsPage docDetailsPage) {
        if(alfrescoVersion.equals(AlfrescoVersion.Enterprise4_1) || alfrescoVersion.isCloud()){
           
            // Open Site Document Library
            DocumentLibraryPage libraryPage = ShareUser.openDocumentLibrary(drone).render(maxWaitTime);
            
            Assert.assertTrue(libraryPage.hasFiles());
            
            // Get uploaded files list
            List<FileDirectoryInfo> files = libraryPage.getFiles();
            
            for (FileDirectoryInfo file : files) {
                if ( file.getName().equalsIgnoreCase(fileName) ) {
                    docDetailsPage = libraryPage.selectFile(file.getName()).render();
                    
                    Assert.assertTrue(docDetailsPage.isNoPreviewMessageDisplayed());
                }
            }
        }
        return docDetailsPage;
    }
 
    /**
     * This method clicks on download link present on unsupported documents details page instead of detail preview.  And this is applicable to Enterprise versions only.
     * @param docDetailsPage
     */
    private void clickOnDownloadLink(DocumentDetailsPage docDetailsPage) {
        if(alfrescoVersion.equals(AlfrescoVersion.Enterprise4_1) ){
            docDetailsPage.clickOnDownloadLinkForUnsupportedDocument();
        }
    }
}