/*
 * Copyright (c) 1998-2006 Caucho Technology -- all rights reserved
 *
 * This file is part of Resin(R) Open Source
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * Resin Open Source is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Resin Open Source is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, or any warranty
 * of NON-INFRINGEMENT.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Resin Open Source; if not, write to the
 *
 *   Free Software Foundation, Inc.
 *   59 Temple Place, Suite 330
 *   Boston, MA 02111-1307  USA
 *
 * @author Scott Ferguson
 */

package com.caucho.quercus.lib;

import com.caucho.quercus.QuercusException;
import com.caucho.quercus.annotation.Optional;
import com.caucho.quercus.annotation.Reference;
import com.caucho.quercus.env.BooleanValue;
import com.caucho.quercus.env.Env;
import com.caucho.quercus.env.LongValue;
import com.caucho.quercus.env.Value;
import com.caucho.quercus.module.AbstractQuercusModule;
import com.caucho.util.L10N;
import com.caucho.vfs.Path;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import java.io.IOException;
import java.util.Iterator;


/**
 * PHP exif
 */
public class ExifModule extends AbstractQuercusModule {
  private static final L10N L = new L10N(ExifModule.class);

  /**
   *  Reads the EXIF headers from JPEG or TIFF
   */
  public static Value exif_read_data(Env env, Path file,
				     @Optional String sections,
				     @Optional boolean arrays,
				     @Optional boolean thumbs)
  {
    return BooleanValue.FALSE;
  }

  /**
   *  Alias of exif_read_data()
   */
  public static Value read_exif_data(Env env, Path file,
				     @Optional String sections,
				     @Optional boolean arrays,
				     @Optional boolean thumbs)
  {
    return exif_read_data(env, file, sections, arrays, thumbs);
  }

  /**
   *  Retrieve the embedded thumbnail of a TIFF or JPEG image
   *  @param filename the name of the image file being read.
   *  @param width the width of the returned thumbnail
   *  @param height the height of the returned thumbnail
   *  @param imagetype either TIFF or JPEG
   *  @return either the thumbnail or FALSE
   */
  public static Value exif_thumbnail(Env env, Path file,
				     @Optional @Reference int width,
				     @Optional @Reference int height,
				     @Optional @Reference int imageType)
  {
    return BooleanValue.FALSE;
  }

  /**
   *  Get the header name for an index
   */
  public static String exif_tagname(String index)
  {
    return null;
  }

  /**
   *  Determine the type of an image
   */
  public static Value exif_imagetype(Env env, Path file)
  {
    try {
      Iterator it = ImageIO.getImageReaders(file.openRead());
      if (!it.hasNext())
	return BooleanValue.FALSE;
      ImageReader imageReader = (ImageReader)it.next();
      if (it.hasNext())
	throw new QuercusException("ImageIO returned two ImageReaders:\n  "+
				   imageReader+"\n  "+it.next());
      String formatName = imageReader.getFormatName();
      if (formatName.equals("jpeg") || formatName.equals("jpg"))
	return LongValue.create(ImageModule.IMAGETYPE_JPG);
      if (formatName.equals("gif"))
	return LongValue.create(ImageModule.IMAGETYPE_GIF);
      if (formatName.equals("png"))
	return LongValue.create(ImageModule.IMAGETYPE_PNG);
      if (formatName.equals("swf"))
	return LongValue.create(ImageModule.IMAGETYPE_SWF);
      if (formatName.equals("psd"))
	return LongValue.create(ImageModule.IMAGETYPE_PSD);
      if (formatName.equals("bmp"))
	return LongValue.create(ImageModule.IMAGETYPE_BMP);
      if (formatName.equals("tiff"))
	return LongValue.create(ImageModule.IMAGETYPE_TIFF_II);
      /*
      // XXX: check byte order
      if (formatName.equals("tiff"))
      return ImageModule.IMAGETYPE_TIFF_MM;
      */
      if (formatName.equals("jpc"))
	return LongValue.create(ImageModule.IMAGETYPE_JPC);
      if (formatName.equals("jp2"))
	return LongValue.create(ImageModule.IMAGETYPE_JP2);
      if (formatName.equals("jpf"))
	return LongValue.create(ImageModule.IMAGETYPE_JPX);
      if (formatName.equals("jb2"))
	return LongValue.create(ImageModule.IMAGETYPE_JB2);
      if (formatName.equals("swc"))
	return LongValue.create(ImageModule.IMAGETYPE_SWC);
      if (formatName.equals("iff"))
	return LongValue.create(ImageModule.IMAGETYPE_IFF);
      if (formatName.equals("wbmp"))
	return LongValue.create(ImageModule.IMAGETYPE_WBMP);
      if (formatName.equals("xbm"))
	return LongValue.create(ImageModule.IMAGETYPE_XBM);
      env.warning(L.l("ImageIO returned unknown image type: " + formatName));
      return BooleanValue.FALSE;
    }
    catch (IOException e)
      {
	throw new QuercusException(e);
      }
  }



}

